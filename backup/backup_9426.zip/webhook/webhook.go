// Package webhook provides webhook notification capabilities for MIRA async events.
package webhook

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"sync"
	"time"

	"github.com/google/uuid"
)

// EventType represents the type of webhook event
type EventType string

const (
	EventEmbeddingCompleted EventType = "embedding.completed"
	EventEmbeddingFailed    EventType = "embedding.failed"
	EventStoreCompleted     EventType = "store.completed"
	EventCausalDetected     EventType = "causal.detected"
	EventIndexMaintenance   EventType = "index.maintenance"
)

// Event represents a webhook event
type Event struct {
	ID        uuid.UUID       `json:"id"`
	Type      EventType       `json:"type"`
	Timestamp time.Time       `json:"timestamp"`
	Data      json.RawMessage `json:"data"`
}

// EventDataEmbedding contains data for embedding events
type EventDataEmbedding struct {
	JobID         uuid.UUID `json:"job_id"`
	VerbatimID    uuid.UUID `json:"verbatim_id"`
	FingerprintID uuid.UUID `json:"fingerprint_id,omitempty"`
	Duration      int64     `json:"duration_ms"`
	Error         string    `json:"error,omitempty"`
}

// EventDataCausal contains data for causal detection events
type EventDataCausal struct {
	FingerprintID uuid.UUID   `json:"fingerprint_id"`
	EdgesCreated  int         `json:"edges_created"`
	RelatedIDs    []uuid.UUID `json:"related_ids"`
}

// Webhook represents a webhook configuration
type Webhook struct {
	ID        uuid.UUID
	URL       string
	Events    []EventType
	Secret    string // For HMAC signature
	Active    bool
	CreatedAt time.Time
}

// Manager manages webhook subscriptions and delivery
type Manager struct {
	webhooks map[uuid.UUID]*Webhook
	client   *http.Client
	mu       sync.RWMutex
	queue    chan *Event
	workers  int
	wg       sync.WaitGroup
	ctx      context.Context
	cancel   context.CancelFunc
}

// ManagerOptions configures the webhook manager
type ManagerOptions struct {
	Workers       int
	QueueSize     int
	Timeout       time.Duration
	RetryAttempts int
	RetryDelay    time.Duration
}

// DefaultManagerOptions returns sensible defaults
func DefaultManagerOptions() ManagerOptions {
	return ManagerOptions{
		Workers:       3,
		QueueSize:     1000,
		Timeout:       30 * time.Second,
		RetryAttempts: 3,
		RetryDelay:    5 * time.Second,
	}
}

// NewManager creates a new webhook manager
func NewManager(opts ManagerOptions) *Manager {
	if opts.Workers <= 0 {
		opts.Workers = 3
	}
	if opts.QueueSize <= 0 {
		opts.QueueSize = 1000
	}
	if opts.Timeout <= 0 {
		opts.Timeout = 30 * time.Second
	}

	ctx, cancel := context.WithCancel(context.Background())

	m := &Manager{
		webhooks: make(map[uuid.UUID]*Webhook),
		client: &http.Client{
			Timeout: opts.Timeout,
		},
		queue:   make(chan *Event, opts.QueueSize),
		workers: opts.Workers,
		ctx:     ctx,
		cancel:  cancel,
	}

	return m
}

// Start begins processing webhook events
func (m *Manager) Start() {
	for i := 0; i < m.workers; i++ {
		m.wg.Add(1)
		go m.worker(i)
	}
	log.Printf("Webhook manager started with %d workers", m.workers)
}

// Stop gracefully shuts down the webhook manager
func (m *Manager) Stop() {
	m.cancel()
	close(m.queue)
	m.wg.Wait()
	log.Println("Webhook manager stopped")
}

// Register adds a new webhook
func (m *Manager) Register(url string, events []EventType, secret string) *Webhook {
	wh := &Webhook{
		ID:        uuid.New(),
		URL:       url,
		Events:    events,
		Secret:    secret,
		Active:    true,
		CreatedAt: time.Now(),
	}

	m.mu.Lock()
	m.webhooks[wh.ID] = wh
	m.mu.Unlock()

	log.Printf("Registered webhook %s for URL %s", wh.ID, url)
	return wh
}

// Unregister removes a webhook
func (m *Manager) Unregister(id uuid.UUID) {
	m.mu.Lock()
	delete(m.webhooks, id)
	m.mu.Unlock()
	log.Printf("Unregistered webhook %s", id)
}

// Trigger sends an event to all subscribed webhooks
func (m *Manager) Trigger(eventType EventType, data interface{}) {
	select {
	case <-m.ctx.Done():
		log.Printf("Webhook manager shutting down, dropping event %s", eventType)
		return
	default:
	}

	dataJSON, err := json.Marshal(data)
	if err != nil {
		log.Printf("Failed to marshal webhook event data: %v", err)
		return
	}

	event := &Event{
		ID:        uuid.New(),
		Type:      eventType,
		Timestamp: time.Now(),
		Data:      dataJSON,
	}

	select {
	case m.queue <- event:
		// Event queued successfully
	default:
		log.Printf("Webhook queue full, dropping event %s", eventType)
	}
}

// worker processes webhook events
func (m *Manager) worker(id int) {
	defer m.wg.Done()

	for event := range m.queue {
		delivered := m.deliverEvent(event)
		if !delivered {
			log.Printf("Failed to deliver event %s to any webhook", event.ID)
		}
	}
}

// deliverEvent sends an event to all matching webhooks
func (m *Manager) deliverEvent(event *Event) bool {
	m.mu.RLock()
	webhooks := make([]*Webhook, 0, len(m.webhooks))
	for _, wh := range m.webhooks {
		if wh.Active && m.isSubscribed(wh, event.Type) {
			webhooks = append(webhooks, wh)
		}
	}
	m.mu.RUnlock()

	if len(webhooks) == 0 {
		return true // No webhooks to deliver to, considered success
	}

	anyDelivered := false
	for _, wh := range webhooks {
		if err := m.sendWebhook(wh, event); err != nil {
			log.Printf("Failed to send webhook to %s: %v", wh.URL, err)
		} else {
			anyDelivered = true
		}
	}

	return anyDelivered
}

// isSubscribed checks if a webhook is subscribed to an event type
func (m *Manager) isSubscribed(wh *Webhook, eventType EventType) bool {
	for _, et := range wh.Events {
		if et == eventType || string(et) == "*" {
			return true
		}
	}
	return false
}

// sendWebhook sends a single webhook request
func (m *Manager) sendWebhook(wh *Webhook, event *Event) error {
	payload, err := json.Marshal(event)
	if err != nil {
		return fmt.Errorf("failed to marshal event: %w", err)
	}

	req, err := http.NewRequestWithContext(m.ctx, "POST", wh.URL, bytes.NewBuffer(payload))
	if err != nil {
		return fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-MIRA-Event-ID", event.ID.String())
	req.Header.Set("X-MIRA-Event-Type", string(event.Type))
	req.Header.Set("X-MIRA-Webhook-ID", wh.ID.String())

	// Add HMAC signature if secret is configured
	if wh.Secret != "" {
		signature := m.sign(payload, wh.Secret)
		req.Header.Set("X-MIRA-Signature", signature)
	}

	resp, err := m.client.Do(req)
	if err != nil {
		return fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("webhook returned status %d", resp.StatusCode)
	}

	return nil
}

// sign creates an HMAC signature (simplified, should use crypto/hmac in production)
func (m *Manager) sign(payload []byte, secret string) string {
	// In production, use crypto/hmac with sha256
	// This is a placeholder
	return fmt.Sprintf("sha256=%x", payload)
}

// ListWebhooks returns all registered webhooks
func (m *Manager) ListWebhooks() []*Webhook {
	m.mu.RLock()
	defer m.mu.RUnlock()

	webhooks := make([]*Webhook, 0, len(m.webhooks))
	for _, wh := range m.webhooks {
		webhooks = append(webhooks, wh)
	}
	return webhooks
}

// GetStats returns webhook statistics
func (m *Manager) GetStats() WebhookStats {
	return WebhookStats{
		RegisteredCount: len(m.webhooks),
		QueueDepth:      len(m.queue),
	}
}

// WebhookStats holds statistics about webhook delivery
type WebhookStats struct {
	RegisteredCount int
	QueueDepth      int
}
