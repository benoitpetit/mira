package webhook

import (
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/google/uuid"
)

func TestNewManager(t *testing.T) {
	opts := DefaultManagerOptions()
	m := NewManager(opts)
	
	if m == nil {
		t.Fatal("Expected manager to be created")
	}
	
	if m.workers != opts.Workers {
		t.Errorf("Expected %d workers, got %d", opts.Workers, m.workers)
	}
	
	if cap(m.queue) != opts.QueueSize {
		t.Errorf("Expected queue size %d, got %d", opts.QueueSize, cap(m.queue))
	}
}

func TestManager_Register(t *testing.T) {
	m := NewManager(DefaultManagerOptions())
	
	events := []EventType{EventEmbeddingCompleted, EventStoreCompleted}
	wh := m.Register("http://example.com/webhook", events, "secret123")
	
	if wh.ID == uuid.Nil {
		t.Error("Expected webhook to have an ID")
	}
	
	if wh.URL != "http://example.com/webhook" {
		t.Errorf("Expected URL http://example.com/webhook, got %s", wh.URL)
	}
	
	if len(wh.Events) != 2 {
		t.Errorf("Expected 2 events, got %d", len(wh.Events))
	}
	
	if wh.Secret != "secret123" {
		t.Error("Expected secret to be set")
	}
	
	if !wh.Active {
		t.Error("Expected webhook to be active")
	}
}

func TestManager_Unregister(t *testing.T) {
	m := NewManager(DefaultManagerOptions())
	
	wh := m.Register("http://example.com/webhook", []EventType{EventEmbeddingCompleted}, "")
	
	if len(m.webhooks) != 1 {
		t.Fatal("Expected 1 webhook registered")
	}
	
	m.Unregister(wh.ID)
	
	if len(m.webhooks) != 0 {
		t.Error("Expected webhook to be unregistered")
	}
}

func TestManager_Trigger(t *testing.T) {
	// Create a test HTTP server
	received := make(chan *Event, 1)
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		body, _ := io.ReadAll(r.Body)
		var event Event
		json.Unmarshal(body, &event)
		received <- &event
		w.WriteHeader(http.StatusOK)
	}))
	defer server.Close()
	
	// Create manager and register webhook
	opts := ManagerOptions{
		Workers:   1,
		QueueSize: 10,
		Timeout:   5 * time.Second,
	}
	m := NewManager(opts)
	m.Register(server.URL, []EventType{EventEmbeddingCompleted}, "")
	m.Start()
	defer m.Stop()
	
	// Trigger event
	data := EventDataEmbedding{
		JobID:      uuid.New(),
		VerbatimID: uuid.New(),
		Duration:   100,
	}
	m.Trigger(EventEmbeddingCompleted, data)
	
	// Wait for webhook to be received
	select {
	case event := <-received:
		if event.Type != EventEmbeddingCompleted {
			t.Errorf("Expected event type %s, got %s", EventEmbeddingCompleted, event.Type)
		}
		
		var receivedData EventDataEmbedding
		json.Unmarshal(event.Data, &receivedData)
		if receivedData.Duration != 100 {
			t.Errorf("Expected duration 100, got %d", receivedData.Duration)
		}
		
	case <-time.After(2 * time.Second):
		t.Error("Timeout waiting for webhook")
	}
}

func TestManager_TriggerNoSubscribers(t *testing.T) {
	m := NewManager(DefaultManagerOptions())
	m.Start()
	defer m.Stop()
	
	// Trigger event without subscribers - should not panic or error
	data := EventDataEmbedding{
		JobID:      uuid.New(),
		VerbatimID: uuid.New(),
		Duration:   100,
	}
	
	// Should not block or error
	m.Trigger(EventEmbeddingCompleted, data)
	
	// Give it a moment
	time.Sleep(100 * time.Millisecond)
}

func TestManager_TriggerQueueFull(t *testing.T) {
	// Create a slow test server
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		time.Sleep(500 * time.Millisecond)
		w.WriteHeader(http.StatusOK)
	}))
	defer server.Close()
	
	// Create manager with small queue
	opts := ManagerOptions{
		Workers:   1,
		QueueSize: 2,
		Timeout:   1 * time.Second,
	}
	m := NewManager(opts)
	m.Register(server.URL, []EventType{EventEmbeddingCompleted}, "")
	m.Start()
	defer m.Stop()
	
	// Fill the queue
	for i := 0; i < 10; i++ {
		data := EventDataEmbedding{
			JobID:      uuid.New(),
			VerbatimID: uuid.New(),
			Duration:   int64(i),
		}
		m.Trigger(EventEmbeddingCompleted, data)
	}
	
	// Should not panic even with full queue
	time.Sleep(100 * time.Millisecond)
}

func TestManager_isSubscribed(t *testing.T) {
	m := NewManager(DefaultManagerOptions())
	
	wh := &Webhook{
		Events: []EventType{EventEmbeddingCompleted, EventStoreCompleted},
	}
	
	if !m.isSubscribed(wh, EventEmbeddingCompleted) {
		t.Error("Expected to be subscribed to EventEmbeddingCompleted")
	}
	
	if !m.isSubscribed(wh, EventStoreCompleted) {
		t.Error("Expected to be subscribed to EventStoreCompleted")
	}
	
	if m.isSubscribed(wh, EventCausalDetected) {
		t.Error("Expected not to be subscribed to EventCausalDetected")
	}
}

func TestManager_isSubscribed_Wildcard(t *testing.T) {
	m := NewManager(DefaultManagerOptions())
	
	wh := &Webhook{
		Events: []EventType{"*"},
	}
	
	if !m.isSubscribed(wh, EventEmbeddingCompleted) {
		t.Error("Expected wildcard to match all events")
	}
	
	if !m.isSubscribed(wh, EventStoreCompleted) {
		t.Error("Expected wildcard to match all events")
	}
}

func TestManager_sendWebhook(t *testing.T) {
	// Create a test server that returns 200
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Check headers
		if r.Header.Get("Content-Type") != "application/json" {
			t.Error("Expected Content-Type: application/json")
		}
		
		if r.Header.Get("X-MIRA-Event-Type") != string(EventEmbeddingCompleted) {
			t.Error("Expected X-MIRA-Event-Type header")
		}
		
		w.WriteHeader(http.StatusOK)
	}))
	defer server.Close()
	
	m := NewManager(DefaultManagerOptions())
	
	event := &Event{
		ID:        uuid.New(),
		Type:      EventEmbeddingCompleted,
		Timestamp: time.Now(),
		Data:      json.RawMessage(`{"test": "data"}`),
	}
	
	wh := &Webhook{
		ID:     uuid.New(),
		URL:    server.URL,
		Events: []EventType{EventEmbeddingCompleted},
	}
	
	err := m.sendWebhook(wh, event)
	if err != nil {
		t.Errorf("Expected no error, got %v", err)
	}
}

func TestManager_sendWebhook_ErrorStatus(t *testing.T) {
	// Create a test server that returns error
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusInternalServerError)
	}))
	defer server.Close()
	
	m := NewManager(DefaultManagerOptions())
	
	event := &Event{
		ID:   uuid.New(),
		Type: EventEmbeddingCompleted,
		Data: json.RawMessage(`{}`),
	}
	
	wh := &Webhook{
		ID:  uuid.New(),
		URL: server.URL,
	}
	
	err := m.sendWebhook(wh, event)
	if err == nil {
		t.Error("Expected error for non-2xx status")
	}
}

func TestManager_ListWebhooks(t *testing.T) {
	m := NewManager(DefaultManagerOptions())
	
	// Initially empty
	webhooks := m.ListWebhooks()
	if len(webhooks) != 0 {
		t.Errorf("Expected 0 webhooks initially, got %d", len(webhooks))
	}
	
	// Register some webhooks
	m.Register("http://example.com/1", []EventType{EventEmbeddingCompleted}, "")
	m.Register("http://example.com/2", []EventType{EventStoreCompleted}, "")
	
	webhooks = m.ListWebhooks()
	if len(webhooks) != 2 {
		t.Errorf("Expected 2 webhooks, got %d", len(webhooks))
	}
}

func TestManager_GetStats(t *testing.T) {
	m := NewManager(DefaultManagerOptions())
	
	stats := m.GetStats()
	if stats.RegisteredCount != 0 {
		t.Errorf("Expected 0 registered webhooks, got %d", stats.RegisteredCount)
	}
	
	m.Register("http://example.com/webhook", []EventType{EventEmbeddingCompleted}, "")
	
	stats = m.GetStats()
	if stats.RegisteredCount != 1 {
		t.Errorf("Expected 1 registered webhook, got %d", stats.RegisteredCount)
	}
}

func TestManager_StartStop(t *testing.T) {
	m := NewManager(DefaultManagerOptions())
	
	m.Start()
	
	// Give workers time to start
	time.Sleep(50 * time.Millisecond)
	
	m.Stop()
	
	// Should be able to stop cleanly
	select {
	case <-time.After(100 * time.Millisecond):
		// Success
	default:
		// Also success - just checking no panic
	}
}

func TestEventDataSerialization(t *testing.T) {
	// Test Embedding event data
	embData := EventDataEmbedding{
		JobID:         uuid.New(),
		VerbatimID:    uuid.New(),
		FingerprintID: uuid.New(),
		Duration:      150,
		Error:         "",
	}
	
	jsonData, err := json.Marshal(embData)
	if err != nil {
		t.Fatalf("Failed to marshal embedding data: %v", err)
	}
	
	var decoded EventDataEmbedding
	if err := json.Unmarshal(jsonData, &decoded); err != nil {
		t.Fatalf("Failed to unmarshal embedding data: %v", err)
	}
	
	if decoded.Duration != 150 {
		t.Errorf("Expected duration 150, got %d", decoded.Duration)
	}
	
	// Test Causal event data
	causalData := EventDataCausal{
		FingerprintID: uuid.New(),
		EdgesCreated:  3,
		RelatedIDs:    []uuid.UUID{uuid.New(), uuid.New()},
	}
	
	jsonData, err = json.Marshal(causalData)
	if err != nil {
		t.Fatalf("Failed to marshal causal data: %v", err)
	}
	
	var decodedCausal EventDataCausal
	if err := json.Unmarshal(jsonData, &decodedCausal); err != nil {
		t.Fatalf("Failed to unmarshal causal data: %v", err)
	}
	
	if decodedCausal.EdgesCreated != 3 {
		t.Errorf("Expected 3 edges created, got %d", decodedCausal.EdgesCreated)
	}
}
