// Package metrics provides performance monitoring and metrics collection for MIRA.
// It tracks latencies, throughput, and operational statistics.
package metrics

import (
	"fmt"
	"math"
	"sync"
	"sync/atomic"
	"time"
)

// MetricType categorizes different types of metrics
type MetricType string

const (
	MetricTypeCounter   MetricType = "counter"
	MetricTypeGauge     MetricType = "gauge"
	MetricTypeHistogram MetricType = "histogram"
	MetricTypeTimer     MetricType = "timer"
)

// Metric represents a single metric with metadata
type Metric struct {
	Name        string
	Type        MetricType
	Description string
	Labels      map[string]string
	Value       float64
	Timestamp   time.Time
}

// Histogram tracks the distribution of values
type Histogram struct {
	name     string
	duration time.Duration
	values   []float64
	mu       sync.RWMutex
	maxSize  int
}

// NewHistogram creates a new histogram with a time window
func NewHistogram(name string, duration time.Duration) *Histogram {
	h := &Histogram{
		name:     name,
		duration: duration,
		values:   make([]float64, 0),
		maxSize:  10000,
	}
	go h.cleanupLoop()
	return h
}

// Record adds a value to the histogram
func (h *Histogram) Record(value float64) {
	h.mu.Lock()
	defer h.mu.Unlock()
	
	if len(h.values) >= h.maxSize {
		// Remove oldest 10%
		h.values = h.values[len(h.values)/10:]
	}
	h.values = append(h.values, value)
}

// Stats returns histogram statistics
func (h *Histogram) Stats() HistogramStats {
	h.mu.RLock()
	defer h.mu.RUnlock()
	
	if len(h.values) == 0 {
		return HistogramStats{}
	}

	stats := HistogramStats{
		Count: len(h.values),
		Min:   h.values[0],
		Max:   h.values[0],
		Sum:   0,
	}

	for _, v := range h.values {
		if v < stats.Min {
			stats.Min = v
		}
		if v > stats.Max {
			stats.Max = v
		}
		stats.Sum += v
	}

	stats.Mean = stats.Sum / float64(stats.Count)

	// Calculate percentiles
	if stats.Count > 0 {
		stats.P50 = percentile(h.values, 0.5)
		stats.P90 = percentile(h.values, 0.9)
		stats.P95 = percentile(h.values, 0.95)
		stats.P99 = percentile(h.values, 0.99)
	}

	return stats
}

func (h *Histogram) cleanupLoop() {
	ticker := time.NewTicker(h.duration / 10)
	defer ticker.Stop()

	for range ticker.C {
		h.mu.Lock()
		// Note: In a real implementation, we'd track timestamps per value
		// For simplicity, we just trim the oldest values when max size reached
		if len(h.values) > h.maxSize/2 {
			h.values = h.values[len(h.values)/2:]
		}
		h.mu.Unlock()
	}
}

// HistogramStats holds calculated statistics
type HistogramStats struct {
	Count int
	Min   float64
	Max   float64	
	Mean  float64
	Sum   float64
	P50   float64
	P90   float64
	P95   float64
	P99   float64
}

func percentile(values []float64, p float64) float64 {
	if len(values) == 0 {
		return 0
	}
	
	// Simple implementation - sort and pick index
	// In production, use a more efficient algorithm
	sorted := make([]float64, len(values))
	copy(sorted, values)
	
	// Bubble sort for simplicity (use sort.Float64s in production)
	for i := 0; i < len(sorted); i++ {
		for j := i + 1; j < len(sorted); j++ {
			if sorted[j] < sorted[i] {
				sorted[i], sorted[j] = sorted[j], sorted[i]
			}
		}
	}

	index := int(float64(len(sorted)-1) * p)
	return sorted[index]
}

// Registry holds all metrics
type Registry struct {
	counters   map[string]*Counter
	gauges     map[string]*Gauge
	histograms map[string]*Histogram
	timers     map[string]*Timer
	mu         sync.RWMutex
	startTime  time.Time
}

// NewRegistry creates a new metrics registry
func NewRegistry() *Registry {
	return &Registry{
		counters:   make(map[string]*Counter),
		gauges:     make(map[string]*Gauge),
		histograms: make(map[string]*Histogram),
		timers:     make(map[string]*Timer),
		startTime:  time.Now(),
	}
}

// Counter is a monotonically increasing counter
type Counter struct {
	name  string
	value int64
}

// NewCounter creates or gets a counter
func (r *Registry) NewCounter(name string) *Counter {
	r.mu.Lock()
	defer r.mu.Unlock()
	
	if c, ok := r.counters[name]; ok {
		return c
	}
	
	c := &Counter{name: name}
	r.counters[name] = c
	return c
}

// Inc increments the counter by 1
func (c *Counter) Inc() {
	atomic.AddInt64(&c.value, 1)
}

// Add adds n to the counter
func (c *Counter) Add(n int64) {
	atomic.AddInt64(&c.value, n)
}

// Value returns the current value
func (c *Counter) Value() int64 {
	return atomic.LoadInt64(&c.value)
}

// Gauge is a value that can go up or down
type Gauge struct {
	name  string
	value uint64 // Stores float64 bits for atomic operations
}

// NewGauge creates or gets a gauge
func (r *Registry) NewGauge(name string) *Gauge {
	r.mu.Lock()
	defer r.mu.Unlock()
	
	if g, ok := r.gauges[name]; ok {
		return g
	}
	
	g := &Gauge{name: name}
	r.gauges[name] = g
	return g
}

// Set sets the gauge value
func (g *Gauge) Set(value float64) {
	atomic.StoreUint64(&g.value, math.Float64bits(value))
}

// Inc increments the gauge by 1
func (g *Gauge) Inc() {
	for {
		oldBits := atomic.LoadUint64(&g.value)
		oldVal := math.Float64frombits(oldBits)
		newVal := oldVal + 1
		newBits := math.Float64bits(newVal)
		if atomic.CompareAndSwapUint64(&g.value, oldBits, newBits) {
			return
		}
	}
}

// Dec decrements the gauge by 1
func (g *Gauge) Dec() {
	for {
		oldBits := atomic.LoadUint64(&g.value)
		oldVal := math.Float64frombits(oldBits)
		newVal := oldVal - 1
		newBits := math.Float64bits(newVal)
		if atomic.CompareAndSwapUint64(&g.value, oldBits, newBits) {
			return
		}
	}
}

// Value returns the current value
func (g *Gauge) Value() float64 {
	return math.Float64frombits(atomic.LoadUint64(&g.value))
}

// NewHistogram creates or gets a histogram
func (r *Registry) NewHistogram(name string, duration time.Duration) *Histogram {
	r.mu.Lock()
	defer r.mu.Unlock()
	
	if h, ok := r.histograms[name]; ok {
		return h
	}
	
	h := NewHistogram(name, duration)
	r.histograms[name] = h
	return h
}

// Timer measures durations
type Timer struct {
	name      string
	histogram *Histogram
}

// NewTimer creates or gets a timer
func (r *Registry) NewTimer(name string) *Timer {
	r.mu.Lock()
	defer r.mu.Unlock()
	
	if t, ok := r.timers[name]; ok {
		return t
	}
	
	t := &Timer{
		name:      name,
		histogram: NewHistogram(name+"_duration", time.Hour),
	}
	r.timers[name] = t
	return t
}

// Time records a duration
func (t *Timer) Time(duration time.Duration) {
	t.histogram.Record(float64(duration.Milliseconds()))
}

// Start begins a timer and returns a function to stop it
func (t *Timer) Start() func() {
	start := time.Now()
	return func() {
		t.Time(time.Since(start))
	}
}

// Stats returns timer statistics
func (t *Timer) Stats() HistogramStats {
	return t.histogram.Stats()
}

// MIRAMetrics holds all MIRA-specific metrics
type MIRAMetrics struct {
	registry *Registry
	
	// Operation counters
	StoreOps        *Counter
	RecallOps       *Counter
	LoadOps         *Counter
	CausalOps       *Counter
	
	// Latency timers (ms)
	StoreLatency    *Timer
	RecallLatency   *Timer
	SearchLatency   *Timer
	EmbedLatency    *Timer
	
	// Throughput gauges
	ActiveSearches  *Gauge
	PendingEmbeds   *Gauge
	QueueDepth      *Gauge
	
	// Quality metrics
	CacheHitRate    *Gauge
	HNSWHitRate     *Gauge
	
	// System metrics
	MemoryUsage     *Gauge
	DBSize          *Gauge
}

// NewMIRAMetrics creates a new MIRA metrics instance
func NewMIRAMetrics() *MIRAMetrics {
	r := NewRegistry()
	
	return &MIRAMetrics{
		registry:      r,
		StoreOps:      r.NewCounter("mira_store_operations_total"),
		RecallOps:     r.NewCounter("mira_recall_operations_total"),
		LoadOps:       r.NewCounter("mira_load_operations_total"),
		CausalOps:     r.NewCounter("mira_causal_operations_total"),
		StoreLatency:  r.NewTimer("mira_store_latency_ms"),
		RecallLatency: r.NewTimer("mira_recall_latency_ms"),
		SearchLatency: r.NewTimer("mira_search_latency_ms"),
		EmbedLatency:  r.NewTimer("mira_embedding_latency_ms"),
		ActiveSearches: r.NewGauge("mira_active_searches"),
		PendingEmbeds:  r.NewGauge("mira_pending_embeddings"),
		QueueDepth:     r.NewGauge("mira_queue_depth"),
		CacheHitRate:   r.NewGauge("mira_cache_hit_rate"),
		HNSWHitRate:    r.NewGauge("mira_hnsw_hit_rate"),
		MemoryUsage:    r.NewGauge("mira_memory_usage_bytes"),
		DBSize:         r.NewGauge("mira_database_size_bytes"),
	}
}

// RecordStore records a store operation
func (m *MIRAMetrics) RecordStore(latency time.Duration) {
	m.StoreOps.Inc()
	m.StoreLatency.Time(latency)
}

// RecordRecall records a recall operation
func (m *MIRAMetrics) RecordRecall(latency time.Duration) {
	m.RecallOps.Inc()
	m.RecallLatency.Time(latency)
}

// RecordSearch records a search operation
func (m *MIRAMetrics) RecordSearch(latency time.Duration, usedHNSW bool) {
	m.SearchLatency.Time(latency)
	if usedHNSW {
		// Track HNSW usage for hit rate calculation
	}
}

// RecordEmbed records an embedding operation
func (m *MIRAMetrics) RecordEmbed(latency time.Duration) {
	m.EmbedLatency.Time(latency)
}

// GetReport generates a comprehensive metrics report
func (m *MIRAMetrics) GetReport() MetricsReport {
	return MetricsReport{
		Timestamp:       time.Now(),
		Uptime:          time.Since(m.registry.startTime),
		StoreOps:        m.StoreOps.Value(),
		RecallOps:       m.RecallOps.Value(),
		StoreLatency:    m.StoreLatency.Stats(),
		RecallLatency:   m.RecallLatency.Stats(),
		SearchLatency:   m.SearchLatency.Stats(),
		EmbedLatency:    m.EmbedLatency.Stats(),
		ActiveSearches:  m.ActiveSearches.Value(),
		PendingEmbeds:   m.PendingEmbeds.Value(),
		QueueDepth:      m.QueueDepth.Value(),
		CacheHitRate:    m.CacheHitRate.Value(),
		HNSWHitRate:     m.HNSWHitRate.Value(),
	}
}

// MetricsReport is a snapshot of all metrics
type MetricsReport struct {
	Timestamp      time.Time
	Uptime         time.Duration
	StoreOps       int64
	RecallOps      int64
	StoreLatency   HistogramStats
	RecallLatency  HistogramStats
	SearchLatency  HistogramStats
	EmbedLatency   HistogramStats
	ActiveSearches float64
	PendingEmbeds  float64
	QueueDepth     float64
	CacheHitRate   float64
	HNSWHitRate    float64
}

// String returns a formatted report
func (r MetricsReport) String() string {
	return fmt.Sprintf(`
╔══════════════════════════════════════════════════════════════╗
║                    MIRA Metrics Report                       ║
╠══════════════════════════════════════════════════════════════╣
║ Timestamp: %-50s ║
║ Uptime:    %-50s ║
╠══════════════════════════════════════════════════════════════╣
║ Operations                                                   ║
║   Store:   %-10d  Recall:  %-10d                 ║
╠══════════════════════════════════════════════════════════════╣
║ Latencies (ms)                                               ║
║   Store:   p50=%6.2f  p90=%6.2f  p99=%6.2f                ║
║   Recall:  p50=%6.2f  p90=%6.2f  p99=%6.2f                ║
║   Search:  p50=%6.2f  p90=%6.2f  p99=%6.2f                ║
║   Embed:   p50=%6.2f  p90=%6.2f  p99=%6.2f                ║
╠══════════════════════════════════════════════════════════════╣
║ Current State                                                ║
║   Active Searches: %-5.0f  Pending Embeds: %-5.0f           ║
║   Queue Depth:     %-5.0f  Cache Hit Rate: %.1f%%            ║
║   HNSW Hit Rate:   %.1f%%                                    ║
╚══════════════════════════════════════════════════════════════╝`,
		r.Timestamp.Format("2006-01-02 15:04:05"),
		r.Uptime.Round(time.Second),
		r.StoreOps, r.RecallOps,
		r.StoreLatency.P50, r.StoreLatency.P90, r.StoreLatency.P99,
		r.RecallLatency.P50, r.RecallLatency.P90, r.RecallLatency.P99,
		r.SearchLatency.P50, r.SearchLatency.P90, r.SearchLatency.P99,
		r.EmbedLatency.P50, r.EmbedLatency.P90, r.EmbedLatency.P99,
		r.ActiveSearches, r.PendingEmbeds, r.QueueDepth,
		r.CacheHitRate, r.HNSWHitRate,
	)
}

// Global registry for convenience
var defaultRegistry = NewRegistry()

// DefaultRegistry returns the global registry
func DefaultRegistry() *Registry {
	return defaultRegistry
}
