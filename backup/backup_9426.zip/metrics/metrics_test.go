package metrics

import (
	"strings"
	"testing"
	"time"
)

func TestNewRegistry(t *testing.T) {
	r := NewRegistry()
	if r == nil {
		t.Fatal("Expected registry to be created")
	}
	
	if r.counters == nil {
		t.Error("Expected counters map to be initialized")
	}
	
	if r.gauges == nil {
		t.Error("Expected gauges map to be initialized")
	}
	
	if r.histograms == nil {
		t.Error("Expected histograms map to be initialized")
	}
}

func TestCounter(t *testing.T) {
	r := NewRegistry()
	c := r.NewCounter("test_counter")
	
	if c.Value() != 0 {
		t.Errorf("Expected initial value 0, got %d", c.Value())
	}
	
	c.Inc()
	if c.Value() != 1 {
		t.Errorf("Expected value 1, got %d", c.Value())
	}
	
	c.Add(5)
	if c.Value() != 6 {
		t.Errorf("Expected value 6, got %d", c.Value())
	}
	
	// Same counter should be returned
	c2 := r.NewCounter("test_counter")
	if c2.Value() != 6 {
		t.Errorf("Expected same counter with value 6, got %d", c2.Value())
	}
}

func TestGauge(t *testing.T) {
	r := NewRegistry()
	g := r.NewGauge("test_gauge")
	
	if g.Value() != 0 {
		t.Errorf("Expected initial value 0, got %f", g.Value())
	}
	
	g.Set(42.5)
	if g.Value() != 42.5 {
		t.Errorf("Expected value 42.5, got %f", g.Value())
	}
	
	g.Inc()
	if g.Value() != 43.5 {
		t.Errorf("Expected value 43.5, got %f", g.Value())
	}
	
	g.Dec()
	if g.Value() != 42.5 {
		t.Errorf("Expected value 42.5, got %f", g.Value())
	}
}

func TestHistogram(t *testing.T) {
	h := NewHistogram("test_histogram", time.Hour)
	
	// Record some values
	values := []float64{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	for _, v := range values {
		h.Record(v)
	}
	
	stats := h.Stats()
	
	if stats.Count != 10 {
		t.Errorf("Expected count 10, got %d", stats.Count)
	}
	
	if stats.Min != 1 {
		t.Errorf("Expected min 1, got %f", stats.Min)
	}
	
	if stats.Max != 10 {
		t.Errorf("Expected max 10, got %f", stats.Max)
	}
	
	// Mean should be around 5.5
	if stats.Mean < 5.4 || stats.Mean > 5.6 {
		t.Errorf("Expected mean around 5.5, got %f", stats.Mean)
	}
	
	// Percentiles
	if stats.P50 < 4 || stats.P50 > 7 {
		t.Errorf("Expected p50 around 5, got %f", stats.P50)
	}
	
	if stats.P90 < 8 || stats.P90 > 10 {
		t.Errorf("Expected p90 around 9, got %f", stats.P90)
	}
}

func TestTimer(t *testing.T) {
	r := NewRegistry()
	timer := r.NewTimer("test_timer")
	
	// Record some durations
	for i := 0; i < 5; i++ {
		timer.Time(time.Duration(i+1) * time.Millisecond)
	}
	
	stats := timer.Stats()
	
	if stats.Count != 5 {
		t.Errorf("Expected count 5, got %d", stats.Count)
	}
}

func TestTimer_Start(t *testing.T) {
	r := NewRegistry()
	timer := r.NewTimer("test_timer")
	
	// Use Start/Stop pattern
	stop := timer.Start()
	time.Sleep(5 * time.Millisecond)
	stop()
	
	stats := timer.Stats()
	
	if stats.Count != 1 {
		t.Errorf("Expected count 1, got %d", stats.Count)
	}
	
	if stats.Min < 4 || stats.Min > 20 {
		t.Errorf("Expected min around 5ms, got %f", stats.Min)
	}
}

func TestNewMIRAMetrics(t *testing.T) {
	m := NewMIRAMetrics()
	if m == nil {
		t.Fatal("Expected MIRAMetrics to be created")
	}
	
	// Check all fields are initialized
	if m.StoreOps == nil {
		t.Error("Expected StoreOps to be initialized")
	}
	
	if m.RecallOps == nil {
		t.Error("Expected RecallOps to be initialized")
	}
	
	if m.StoreLatency == nil {
		t.Error("Expected StoreLatency to be initialized")
	}
	
	if m.ActiveSearches == nil {
		t.Error("Expected ActiveSearches to be initialized")
	}
}

func TestMIRAMetrics_RecordOperations(t *testing.T) {
	m := NewMIRAMetrics()
	
	// Record store operation
	m.RecordStore(10 * time.Millisecond)
	if m.StoreOps.Value() != 1 {
		t.Errorf("Expected store ops 1, got %d", m.StoreOps.Value())
	}
	
	// Record recall operation
	m.RecallOps.Inc()
	m.RecallOps.Inc()
	if m.RecallOps.Value() != 2 {
		t.Errorf("Expected recall ops 2, got %d", m.RecallOps.Value())
	}
	
	// Record search
	m.RecordSearch(5*time.Millisecond, true)
	m.RecordSearch(10*time.Millisecond, false)
	
	// Record embed
	m.RecordEmbed(100 * time.Millisecond)
}

func TestMIRAMetrics_GetReport(t *testing.T) {
	m := NewMIRAMetrics()
	
	// Record some operations
	m.RecordStore(10 * time.Millisecond)
	m.RecordStore(20 * time.Millisecond)
	m.RecordRecall(5 * time.Millisecond)
	m.ActiveSearches.Set(3)
	m.QueueDepth.Set(10)
	
	report := m.GetReport()
	
	if report.StoreOps != 2 {
		t.Errorf("Expected 2 store ops, got %d", report.StoreOps)
	}
	
	if report.RecallOps != 1 {
		t.Errorf("Expected 1 recall op, got %d", report.RecallOps)
	}
	
	if report.ActiveSearches != 3 {
		t.Errorf("Expected 3 active searches, got %f", report.ActiveSearches)
	}
	
	if report.QueueDepth != 10 {
		t.Errorf("Expected queue depth 10, got %f", report.QueueDepth)
	}
	
	// Check latencies are recorded
	if report.StoreLatency.Count != 2 {
		t.Errorf("Expected 2 store latency samples, got %d", report.StoreLatency.Count)
	}
}

func TestMetricsReport_String(t *testing.T) {
	m := NewMIRAMetrics()
	m.RecordStore(10 * time.Millisecond)
	m.RecordRecall(5 * time.Millisecond)
	
	report := m.GetReport()
	s := report.String()
	
	// Check that the report contains expected sections
	if !strings.Contains(s, "MIRA Metrics Report") {
		t.Error("Expected report to contain title")
	}
	
	if !strings.Contains(s, "Operations") {
		t.Error("Expected report to contain Operations section")
	}
	
	if !strings.Contains(s, "Latencies") {
		t.Error("Expected report to contain Latencies section")
	}
}

func TestPercentile(t *testing.T) {
	values := []float64{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	
	tests := []struct {
		p    float64
		want float64
	}{
		{0.0, 1},
		{0.5, 5},
		{0.9, 9},
		{1.0, 10},
	}
	
	for _, tt := range tests {
		got := percentile(values, tt.p)
		// Allow some tolerance due to sorting implementation
		if got < tt.want-1 || got > tt.want+1 {
			t.Errorf("percentile(values, %g) = %g, want around %g", tt.p, got, tt.want)
		}
	}
}

func TestPercentile_Empty(t *testing.T) {
	got := percentile([]float64{}, 0.5)
	if got != 0 {
		t.Errorf("Expected 0 for empty slice, got %f", got)
	}
}

func TestDefaultRegistry(t *testing.T) {
	r1 := DefaultRegistry()
	r2 := DefaultRegistry()
	
	// Should return the same instance
	if r1 != r2 {
		t.Error("Expected DefaultRegistry to return the same instance")
	}
}

func BenchmarkCounter_Inc(b *testing.B) {
	r := NewRegistry()
	c := r.NewCounter("bench_counter")
	
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		c.Inc()
	}
}

func BenchmarkHistogram_Record(b *testing.B) {
	h := NewHistogram("bench_histogram", time.Hour)
	
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		h.Record(float64(i % 100))
	}
}

func BenchmarkTimer_Time(b *testing.B) {
	r := NewRegistry()
	timer := r.NewTimer("bench_timer")
	
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		timer.Time(time.Millisecond)
	}
}
