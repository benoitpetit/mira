package vector

import (
	"fmt"
	"os"
	"path/filepath"
	"sync"

	"github.com/coder/hnsw"
	"github.com/benoitpetit/mira/internal/util"
	"github.com/benoitpetit/mira/types"
	"github.com/google/uuid"
)

// HNSWIndex implements vector search using HNSW algorithm
type HNSWIndex struct {
	graph       *hnsw.Graph[node]
	dimension   int
	indexPath   string
	mu          sync.RWMutex
	idToUUID    map[string]uuid.UUID
	uuidToID    map[uuid.UUID]string
	nextID      int
	store       StoreInterface
	ready       bool  // Indicates if index is ready for queries
}

// node wraps a candidate for HNSW
type node struct {
	id        string
	embedding hnsw.Embedding
}

// ID implements hnsw.Embeddable
func (n node) ID() string {
	return n.id
}

// Embedding implements hnsw.Embeddable
func (n node) Embedding() hnsw.Embedding {
	return n.embedding
}

// HNSWOptions holds configuration for HNSW
type HNSWOptions struct {
	M              int
	Ml             float64
	EfConstruction int
	EfSearch       int
}

// DefaultHNSWOptions returns default HNSW options
func DefaultHNSWOptions() HNSWOptions {
	return HNSWOptions{
		M:              16,
		Ml:             0.25,
		EfConstruction: 200,
		EfSearch:       50,
	}
}

// NewHNSWIndex creates a new HNSW vector index
// The index is initially empty and should be populated via BuildFromStore() or AddCandidate()
func NewHNSWIndex(store StoreInterface, dimension int, indexPath string, opts HNSWOptions) (*HNSWIndex, error) {
	idx := &HNSWIndex{
		store:     store,
		dimension: dimension,
		indexPath: indexPath,
		idToUUID:  make(map[string]uuid.UUID),
		uuidToID:  make(map[uuid.UUID]string),
		nextID:    0,
		ready:     false,
	}

	// Register cosine distance function
	hnsw.RegisterDistanceFunc("cosine", cosineDistance)

	// Create new empty graph
	idx.graph = hnsw.NewGraph[node]()
	idx.applyOptions(opts)

	// Create index directory if needed
	if indexPath != "" {
		if err := os.MkdirAll(filepath.Dir(indexPath), 0755); err != nil {
			return nil, fmt.Errorf("failed to create index directory: %w", err)
		}
	}

	return idx, nil
}

func (idx *HNSWIndex) applyOptions(opts HNSWOptions) {
	idx.graph.M = opts.M
	idx.graph.Ml = opts.Ml
	idx.graph.EfSearch = opts.EfSearch
	idx.graph.Distance = cosineDistance
}

// BuildFromStore rebuilds the HNSW index from all embeddings in SQLite
// This should be called on startup to populate the index
func (idx *HNSWIndex) BuildFromStore() error {
	candidates, err := idx.store.SearchCandidates(nil, nil, 100000)
	if err != nil {
		return fmt.Errorf("failed to load candidates from store: %w", err)
	}

	idx.mu.Lock()
	defer idx.mu.Unlock()

	for _, c := range candidates {
		if len(c.Embedding) != idx.dimension {
			continue // Skip candidates with wrong dimension
		}

		id := fmt.Sprintf("vec_%d", idx.nextID)
		idx.nextID++

		idx.idToUUID[id] = c.Memory.ID
		idx.uuidToID[c.Memory.ID] = id

		emb := make(hnsw.Embedding, len(c.Embedding))
		copy(emb, c.Embedding)

		n := node{
			id:        id,
			embedding: emb,
		}

		idx.graph.Add(n)
	}

	idx.ready = true
	return nil
}

// BuildAsync rebuilds the index in the background
// Returns immediately, index is marked ready when complete
func (idx *HNSWIndex) BuildAsync() {
	go func() {
		if err := idx.BuildFromStore(); err != nil {
			// Log error but don't fail - will use fallback
		}
	}()
}

// IsReady returns true if the index has been populated and is ready for queries
func (idx *HNSWIndex) IsReady() bool {
	idx.mu.RLock()
	defer idx.mu.RUnlock()
	return idx.ready
}

// AddCandidate adds a candidate to the HNSW index
func (idx *HNSWIndex) AddCandidate(c *types.Candidate) error {
	if len(c.Embedding) != idx.dimension {
		return fmt.Errorf("embedding dimension mismatch: expected %d, got %d", idx.dimension, len(c.Embedding))
	}

	idx.mu.Lock()
	defer idx.mu.Unlock()

	id := fmt.Sprintf("vec_%d", idx.nextID)
	idx.nextID++

	idx.idToUUID[id] = c.Memory.ID
	idx.uuidToID[c.Memory.ID] = id

	// Make a copy of embedding
	emb := make(hnsw.Embedding, len(c.Embedding))
	copy(emb, c.Embedding)

	n := node{
		id:        id,
		embedding: emb,
	}

	idx.graph.Add(n)

	return nil
}

// Search performs approximate nearest neighbor search
// If index is not ready or filtering is needed, falls back to SQLite
func (idx *HNSWIndex) Search(vector []float32, limit int, wing, room *string) ([]*types.Candidate, error) {
	if len(vector) != idx.dimension {
		return nil, fmt.Errorf("query dimension mismatch: expected %d, got %d", idx.dimension, len(vector))
	}

	// If filtering is required or index not ready, use fallback search
	if wing != nil || room != nil || !idx.IsReady() {
		return idx.fallbackSearch(vector, limit, wing, room)
	}

	idx.mu.RLock()
	defer idx.mu.RUnlock()

	// Perform HNSW search
	queryVec := make(hnsw.Embedding, len(vector))
	copy(queryVec, vector)
	
	// Get more candidates than needed to account for potential filtering needs
	neighbors := idx.graph.Search(queryVec, limit*2)

	var candidates []*types.Candidate
	for _, n := range neighbors {
		if len(candidates) >= limit {
			break
		}
		
		uuid, ok := idx.idToUUID[n.ID()]
		if !ok {
			continue
		}
		
		// Retrieve full candidate from store
		cand, err := idx.getCandidateByID(uuid)
		if err != nil {
			continue
		}
		
		candidates = append(candidates, cand)
	}

	return candidates, nil
}

func (idx *HNSWIndex) getCandidateByID(id uuid.UUID) (*types.Candidate, error) {
	// Get from store by searching for specific ID
	// This is inefficient but maintains single source of truth in SQLite
	all, err := idx.store.SearchCandidates(nil, nil, 100000)
	if err != nil {
		return nil, err
	}
	
	for _, c := range all {
		if c.Memory.ID == id {
			return c, nil
		}
	}
	
	return nil, fmt.Errorf("candidate not found")
}

// fallbackSearch uses SQLite store when HNSW doesn't have enough results
func (idx *HNSWIndex) fallbackSearch(vector []float32, limit int, wing, room *string) ([]*types.Candidate, error) {
	// Get candidates from store
	candidates, err := idx.store.SearchCandidates(wing, room, limit*2)
	if err != nil {
		return nil, err
	}

	// Score and sort by cosine similarity
	type scored struct {
		cand  *types.Candidate
		score float64
	}

	scoredCandidates := make([]scored, 0, len(candidates))
	for _, c := range candidates {
		if len(c.Embedding) == len(vector) {
			score := util.CosineSimilarity(c.Embedding, vector)
			scoredCandidates = append(scoredCandidates, scored{cand: c, score: score})
		}
	}

	// Sort by descending score (bubble sort for simplicity)
	for i := 0; i < len(scoredCandidates); i++ {
		for j := i + 1; j < len(scoredCandidates); j++ {
			if scoredCandidates[j].score > scoredCandidates[i].score {
				scoredCandidates[i], scoredCandidates[j] = scoredCandidates[j], scoredCandidates[i]
			}
		}
	}

	// Return best
	result := make([]*types.Candidate, 0, min(limit, len(scoredCandidates)))
	for i := 0; i < min(limit, len(scoredCandidates)); i++ {
		result = append(result, scoredCandidates[i].cand)
	}

	return result, nil
}

// Delete removes a candidate from the index
func (idx *HNSWIndex) Delete(id uuid.UUID) error {
	idx.mu.Lock()
	defer idx.mu.Unlock()

	hnswID, ok := idx.uuidToID[id]
	if !ok {
		return nil // Already deleted or never existed
	}

	idx.graph.Delete(hnswID)

	delete(idx.idToUUID, hnswID)
	delete(idx.uuidToID, id)

	return nil
}

// Stats returns index statistics
func (idx *HNSWIndex) Stats() int {
	idx.mu.RLock()
	defer idx.mu.RUnlock()

	return idx.graph.Len()
}

// cosineDistance computes distance for HNSW (lower = closer)
func cosineDistance(a, b []float32) float32 {
	sim := float32(util.CosineSimilarity(a, b))
	return 1.0 - sim
}
