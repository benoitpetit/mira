// Package vector provides load testing and performance benchmarks for HNSW vector search.
// These benchmarks validate the performance characteristics described in the whitepaper.
package vector

import (
	"fmt"
	"runtime"
	"testing"
	"time"

	"github.com/benoitpetit/mira/types"
	"github.com/google/uuid"
)

// BenchmarkHNSWAddScalability tests HNSW add performance at different scales
// This validates the O(log n) insertion complexity claim
func BenchmarkHNSWAddScalability(b *testing.B) {
	sizes := []int{100, 1000, 10000}
	
	for _, size := range sizes {
		b.Run(fmt.Sprintf("size_%d", size), func(b *testing.B) {
			tmpDir := b.TempDir()
			indexPath := tmpDir + "/bench.hnsw"
			store := &mockStore{}
			opts := DefaultHNSWOptions()
			
			idx, _ := NewHNSWIndex(store, 384, indexPath, opts)
			
			// Pre-populate with 'size' vectors
			for i := 0; i < size; i++ {
				c := &types.Candidate{
					Memory:    &types.Fingerprint{ID: uuid.New()},
					Verbatim:  &types.Verbatim{ID: uuid.New()},
					Embedding: randomEmbedding(384, float32(i)),
				}
				idx.AddCandidate(c)
			}
			
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				c := &types.Candidate{
					Memory:    &types.Fingerprint{ID: uuid.New()},
					Verbatim:  &types.Verbatim{ID: uuid.New()},
					Embedding: randomEmbedding(384, float32(size+i)),
				}
				idx.AddCandidate(c)
			}
			
			b.ReportMetric(float64(b.N)/b.Elapsed().Seconds(), "ops/sec")
		})
	}
}

// BenchmarkHNSWSearchScalability tests HNSW search performance at different scales
// This validates the O(log n) search complexity claim from the whitepaper
func BenchmarkHNSWSearchScalability(b *testing.B) {
	sizes := []int{1000, 10000, 50000}
	
	for _, size := range sizes {
		b.Run(fmt.Sprintf("size_%d", size), func(b *testing.B) {
			tmpDir := b.TempDir()
			indexPath := tmpDir + "/bench.hnsw"
			
			// Create candidates
			candidates := make([]*types.Candidate, size)
			for i := 0; i < size; i++ {
				candidates[i] = &types.Candidate{
					Memory: &types.Fingerprint{ID: uuid.New()},
					Verbatim: &types.Verbatim{
						ID:   uuid.New(),
						Wing: "test",
					},
					Embedding: randomEmbedding(384, float32(i)),
				}
			}
			
			store := &mockStore{candidates: candidates}
			opts := DefaultHNSWOptions()
			idx, _ := NewHNSWIndex(store, 384, indexPath, opts)
			
			// Add all candidates
			for _, c := range candidates {
				idx.AddCandidate(c)
			}
			
			query := randomEmbedding(384, float32(size/2))
			
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				idx.Search(query, 10, nil, nil)
			}
			
			// Report metrics
			b.ReportMetric(float64(b.N)/b.Elapsed().Seconds(), "ops/sec")
			latency := float64(b.Elapsed().Microseconds()) / float64(b.N)
			b.ReportMetric(latency, "us/op")
		})
	}
}

// BenchmarkHNSWSearchVsSQLite compares HNSW vs SQLite fallback performance
// Demonstrates the 100x speedup claimed in the whitepaper
func BenchmarkHNSWSearchVsSQLite(b *testing.B) {
	size := 10000
	
	// Create candidates
	candidates := make([]*types.Candidate, size)
	for i := 0; i < size; i++ {
		candidates[i] = &types.Candidate{
			Memory: &types.Fingerprint{ID: uuid.New()},
			Verbatim: &types.Verbatim{
				ID:   uuid.New(),
				Wing: "test",
			},
			Embedding: randomEmbedding(384, float32(i)),
		}
	}
	
	query := randomEmbedding(384, float32(size/2))
	
	b.Run("HNSW", func(b *testing.B) {
		tmpDir := b.TempDir()
		indexPath := tmpDir + "/bench.hnsw"
		store := &mockStore{candidates: candidates}
		opts := DefaultHNSWOptions()
		idx, _ := NewHNSWIndex(store, 384, indexPath, opts)
		
		for _, c := range candidates {
			idx.AddCandidate(c)
		}
		
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			idx.Search(query, 10, nil, nil)
		}
		
		latency := float64(b.Elapsed().Microseconds()) / float64(b.N)
		b.ReportMetric(latency, "us/op")
	})
	
	b.Run("SQLite_Fallback", func(b *testing.B) {
		tmpDir := b.TempDir()
		indexPath := tmpDir + "/bench.hnsw"
		store := &mockStore{candidates: candidates}
		opts := DefaultHNSWOptions()
		idx, _ := NewHNSWIndex(store, 384, indexPath, opts)
		// Don't add candidates to HNSW - force fallback
		
		wing := "test"
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			idx.Search(query, 10, &wing, nil)
		}
		
		latency := float64(b.Elapsed().Microseconds()) / float64(b.N)
		b.ReportMetric(latency, "us/op")
	})
}

// BenchmarkHNSWFilteredSearch tests filtered search performance
func BenchmarkHNSWFilteredSearch(b *testing.B) {
	size := 5000
	
	// Create candidates across different wings
	candidates := make([]*types.Candidate, size)
	wings := []string{"auth", "api", "db", "frontend", "backend"}
	for i := 0; i < size; i++ {
		wing := wings[i%len(wings)]
		room := fmt.Sprintf("room_%d", i%10)
		candidates[i] = &types.Candidate{
			Memory: &types.Fingerprint{ID: uuid.New()},
			Verbatim: &types.Verbatim{
				ID:   uuid.New(),
				Wing: wing,
				Room: &room,
			},
			Embedding: randomEmbedding(384, float32(i)),
		}
	}
	
	store := &mockStore{candidates: candidates}
	tmpDir := b.TempDir()
	indexPath := tmpDir + "/bench.hnsw"
	opts := DefaultHNSWOptions()
	idx, _ := NewHNSWIndex(store, 384, indexPath, opts)
	
	for _, c := range candidates {
		idx.AddCandidate(c)
	}
	
	query := randomEmbedding(384, 1.0)
	
	b.Run("Wing_Filter", func(b *testing.B) {
		wing := "auth"
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			idx.Search(query, 10, &wing, nil)
		}
	})
	
	b.Run("Wing_and_Room_Filter", func(b *testing.B) {
		wing := "auth"
		room := "room_5"
		b.ResetTimer()
		for i := 0; i < b.N; i++ {
			idx.Search(query, 10, &wing, &room)
		}
	})
}

// BenchmarkHNSWConcurrentAccess tests concurrent read/write performance
func BenchmarkHNSWConcurrentAccess(b *testing.B) {
	size := 5000
	concurrencyLevels := []int{1, 4, 8, 16}
	
	// Create candidates
	candidates := make([]*types.Candidate, size)
	for i := 0; i < size; i++ {
		candidates[i] = &types.Candidate{
			Memory: &types.Fingerprint{ID: uuid.New()},
			Verbatim: &types.Verbatim{
				ID:   uuid.New(),
				Wing: "test",
			},
			Embedding: randomEmbedding(384, float32(i)),
		}
	}
	
	for _, concurrency := range concurrencyLevels {
		b.Run(fmt.Sprintf("concurrency_%d", concurrency), func(b *testing.B) {
			tmpDir := b.TempDir()
			indexPath := tmpDir + "/bench.hnsw"
			store := &mockStore{candidates: candidates}
			opts := DefaultHNSWOptions()
			idx, _ := NewHNSWIndex(store, 384, indexPath, opts)
			
			for _, c := range candidates {
				idx.AddCandidate(c)
			}
			
			query := randomEmbedding(384, 1.0)
			
			b.ResetTimer()
			b.RunParallel(func(pb *testing.PB) {
				for pb.Next() {
					idx.Search(query, 10, nil, nil)
				}
			})
			
			throughput := float64(b.N) / b.Elapsed().Seconds()
			b.ReportMetric(throughput, "ops/sec")
		})
	}
}

// BenchmarkHNSWBuildTime tests index build time from SQLite
// This simulates the startup scenario described in the whitepaper
func BenchmarkHNSWBuildTime(b *testing.B) {
	sizes := []int{1000, 10000, 50000}
	
	for _, size := range sizes {
		b.Run(fmt.Sprintf("build_%d", size), func(b *testing.B) {
			candidates := make([]*types.Candidate, size)
			for i := 0; i < size; i++ {
				candidates[i] = &types.Candidate{
					Memory: &types.Fingerprint{ID: uuid.New()},
					Verbatim: &types.Verbatim{
						ID:   uuid.New(),
						Wing: "test",
					},
					Embedding: randomEmbedding(384, float32(i)),
				}
			}
			
			store := &mockStore{candidates: candidates}
			
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				tmpDir := b.TempDir()
				indexPath := tmpDir + "/bench.hnsw"
				opts := DefaultHNSWOptions()
				idx, _ := NewHNSWIndex(store, 384, indexPath, opts)
				idx.BuildFromStore()
			}
			
			buildTime := float64(b.Elapsed().Milliseconds()) / float64(b.N)
			b.ReportMetric(buildTime, "ms/build")
			vectorsPerSec := float64(size) * float64(b.N) / b.Elapsed().Seconds()
			b.ReportMetric(vectorsPerSec, "vectors/sec")
		})
	}
}

// BenchmarkHNSWRecall tests the recall accuracy of HNSW vs exact search
func BenchmarkHNSWRecall(b *testing.B) {
	size := 10000
	k := 10
	
	candidates := make([]*types.Candidate, size)
	for i := 0; i < size; i++ {
		candidates[i] = &types.Candidate{
			Memory: &types.Fingerprint{ID: uuid.New()},
			Verbatim: &types.Verbatim{
				ID:   uuid.New(),
				Wing: "test",
			},
			Embedding: randomEmbedding(384, float32(i)),
		}
	}
	
	store := &mockStore{candidates: candidates}
	tmpDir := b.TempDir()
	indexPath := tmpDir + "/bench.hnsw"
	opts := DefaultHNSWOptions()
	idx, _ := NewHNSWIndex(store, 384, indexPath, opts)
	
	for _, c := range candidates {
		idx.AddCandidate(c)
	}
	
	// Test recall with multiple queries
	totalRecall := 0.0
	numQueries := 100
	
	for q := 0; q < numQueries; q++ {
		query := randomEmbedding(384, float32(q))
		
		// Get HNSW results
		hnswResults, _ := idx.Search(query, k, nil, nil)
		
		// Get exact results (via fallback)
		wing := "test"
		exactResults, _ := idx.Search(query, k, &wing, nil)
		
		// Calculate recall@k
		recall := calculateRecall(hnswResults, exactResults, k)
		totalRecall += recall
	}
	
	avgRecall := totalRecall / float64(numQueries)
	b.ReportMetric(avgRecall*100, "recall_%")
}

// calculateRecall computes recall@k
func calculateRecall(hnswResults, exactResults []*types.Candidate, k int) float64 {
	if len(exactResults) == 0 {
		return 1.0
	}
	
	exactSet := make(map[uuid.UUID]bool)
	for _, r := range exactResults[:min(k, len(exactResults))] {
		exactSet[r.Memory.ID] = true
	}
	
	found := 0
	for _, r := range hnswResults[:min(k, len(hnswResults))] {
		if exactSet[r.Memory.ID] {
			found++
		}
	}
	
	return float64(found) / float64(min(k, len(exactResults)))
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

// BenchmarkHNSWMemoryUsage estimates memory usage per vector
func BenchmarkHNSWMemoryUsage(b *testing.B) {
	sizes := []int{1000, 10000, 50000}
	
	for _, size := range sizes {
		b.Run(fmt.Sprintf("memory_%d", size), func(b *testing.B) {
			tmpDir := b.TempDir()
			indexPath := tmpDir + "/bench.hnsw"
			store := &mockStore{}
			opts := DefaultHNSWOptions()
			idx, _ := NewHNSWIndex(store, 384, indexPath, opts)
			
			// Measure baseline
			var m1 runtime.MemStats
			runtime.GC()
			runtime.ReadMemStats(&m1)
			
			// Add vectors
			for i := 0; i < size; i++ {
				c := &types.Candidate{
					Memory:    &types.Fingerprint{ID: uuid.New()},
					Verbatim:  &types.Verbatim{ID: uuid.New()},
					Embedding: randomEmbedding(384, float32(i)),
				}
				idx.AddCandidate(c)
			}
			
			var m2 runtime.MemStats
			runtime.GC()
			runtime.ReadMemStats(&m2)
			
			// Calculate memory per vector (in bytes)
			memUsed := m2.TotalAlloc - m1.TotalAlloc
			memPerVector := float64(memUsed) / float64(size)
			
			b.ReportMetric(memPerVector, "bytes/vector")
			
			// Also report total memory
			b.ReportMetric(float64(memUsed)/1024/1024, "MB_total")
		})
	}
}

// LoadTestConfig holds configuration for load tests
type LoadTestConfig struct {
	Duration         time.Duration
	NumVectors       int
	QueryRate        int           // queries per second
	WriteRate        int           // writes per second
	Concurrency      int
	Dimension        int
}

// LoadTestResult holds results from a load test
type LoadTestResult struct {
	TotalQueries     int
	TotalWrites      int
	QueryLatencyP50  time.Duration
	QueryLatencyP95  time.Duration
	WriteLatencyP50  time.Duration
	WriteLatencyP95  time.Duration
	Errors           int
	Duration         time.Duration
	Throughput       float64       // ops/sec
}

// RunLoadTest executes a comprehensive load test
func RunLoadTest(cfg LoadTestConfig) (*LoadTestResult, error) {
	// Create test data
	candidates := make([]*types.Candidate, cfg.NumVectors)
	for i := 0; i < cfg.NumVectors; i++ {
		candidates[i] = &types.Candidate{
			Memory: &types.Fingerprint{ID: uuid.New()},
			Verbatim: &types.Verbatim{
				ID:   uuid.New(),
				Wing: "test",
			},
			Embedding: randomEmbedding(cfg.Dimension, float32(i)),
		}
	}
	
	store := &mockStore{candidates: candidates}
	idx, _ := NewHNSWIndex(store, cfg.Dimension, "", DefaultHNSWOptions())
	
	for _, c := range candidates {
		idx.AddCandidate(c)
	}
	
	// Run load test
	result := &LoadTestResult{}
	start := time.Now()
	
	// Implementation would use goroutines and channels
	// to simulate concurrent load
	
	result.Duration = time.Since(start)
	return result, nil
}

// TestHNSWLoad is a functional test (not benchmark) that validates
// HNSW behavior under load conditions
func TestHNSWLoad(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping load test in short mode")
	}
	
	cfg := LoadTestConfig{
		Duration:    5 * time.Second,
		NumVectors:  10000,
		QueryRate:   1000,
		WriteRate:   100,
		Concurrency: 10,
		Dimension:   384,
	}
	
	result, err := RunLoadTest(cfg)
	if err != nil {
		t.Fatalf("Load test failed: %v", err)
	}
	
	t.Logf("Load test results: %+v", result)
	
	// Validate results
	if result.Errors > result.TotalQueries/100 {
		t.Errorf("Too many errors: %d/%d", result.Errors, result.TotalQueries)
	}
	
	if result.QueryLatencyP95 > 100*time.Millisecond {
		t.Errorf("p95 latency too high: %v", result.QueryLatencyP95)
	}
}


