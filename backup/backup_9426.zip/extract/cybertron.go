package extract

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"sync"

	"github.com/nlpodyssey/cybertron/pkg/models/bert"
	"github.com/nlpodyssey/cybertron/pkg/tasks"
	"github.com/nlpodyssey/cybertron/pkg/tasks/textencoding"
)

// CybertronEmbedder implements real embeddings using Cybertron/SentenceTransformers
type CybertronEmbedder struct {
	model    textencoding.Interface
	modelsDir string
	modelName string
	dimension int
	mu        sync.RWMutex
}

// NewCybertronEmbedder creates a new Cybertron embedder
// modelName: e.g., "sentence-transformers/all-MiniLM-L6-v2"
// modelsDir: directory to store downloaded models (e.g., "./mira_data/models")
func NewCybertronEmbedder(modelName, modelsDir string, dimension int) (*CybertronEmbedder, error) {
	// Ensure models directory exists
	if err := os.MkdirAll(modelsDir, 0755); err != nil {
		return nil, fmt.Errorf("failed to create models directory: %w", err)
	}

	// Model path will be used to check if model exists
	_ = filepath.Join(modelsDir, modelName)
	
	// Load the model
	m, err := tasks.Load[textencoding.Interface](&tasks.Config{
		ModelsDir: modelsDir,
		ModelName: modelName,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to load cybertron model %s: %w", modelName, err)
	}

	return &CybertronEmbedder{
		model:     m,
		modelsDir: modelsDir,
		modelName: modelName,
		dimension: dimension,
	}, nil
}

// Encode generates embedding vector for text using Cybertron
func (c *CybertronEmbedder) Encode(text string) ([]float32, error) {
	if text == "" {
		// Return zero vector for empty text
		return make([]float32, c.dimension), nil
	}

	c.mu.RLock()
	defer c.mu.RUnlock()

	ctx := context.Background()
	result, err := c.model.Encode(ctx, text, int(bert.MeanPooling))
	if err != nil {
		return nil, fmt.Errorf("encoding failed: %w", err)
	}

	// Convert to float32
	vec64 := result.Vector.Data().F64()
	vec32 := make([]float32, len(vec64))
	for i, v := range vec64 {
		vec32[i] = float32(v)
	}

	// Ensure correct dimension
	if len(vec32) != c.dimension {
		if len(vec32) > c.dimension {
			vec32 = vec32[:c.dimension]
		} else {
			// Pad with zeros
			padded := make([]float32, c.dimension)
			copy(padded, vec32)
			vec32 = padded
		}
	}

	return vec32, nil
}

// Close releases resources
func (c *CybertronEmbedder) Close() error {
	c.mu.Lock()
	defer c.mu.Unlock()
	
	if c.model != nil {
		tasks.Finalize(c.model)
		c.model = nil
	}
	return nil
}

// ModelName returns the model name
func (c *CybertronEmbedder) ModelName() string {
	return c.modelName
}

// ModelsDir returns the models directory
func (c *CybertronEmbedder) ModelsDir() string {
	return c.modelsDir
}
