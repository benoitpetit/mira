package config

import (
	"os"

	"gopkg.in/yaml.v3"
)

// Config represents complete configuration
type Config struct {
	System            SystemConfig       `yaml:"system"`
	Storage           StorageConfig      `yaml:"storage"`
	Embeddings        EmbeddingsConfig   `yaml:"embeddings"`
	Allocator         AllocatorConfig    `yaml:"allocator"`
	ArchiveThresholds map[string]float64 `yaml:"archive_thresholds"`
	Extraction        ExtractionConfig   `yaml:"extraction"`
	MCP               MCPConfig          `yaml:"mcp"`
	HNSW              HNSWConfig         `yaml:"hnsw"`
	Async             AsyncConfig        `yaml:"async"`
	Metrics           MetricsConfig      `yaml:"metrics"`
	Webhooks          WebhooksConfig     `yaml:"webhooks"`
}

type HNSWConfig struct {
	M              int     `yaml:"M"`
	Ml             float64 `yaml:"Ml"`
	EfConstruction int     `yaml:"ef_construction"`
	EfSearch       int     `yaml:"ef_search"`
}

type SystemConfig struct {
	Version string `yaml:"version"`
}

type StorageConfig struct {
	Path string `yaml:"path"`
}

type EmbeddingsConfig struct {
	CurrentModel string `yaml:"current_model"`
	Dimension    int    `yaml:"dimension"`
	BatchSize    int    `yaml:"batch_size"`
	CacheSize    int    `yaml:"cache_size"`
}

type AllocatorConfig struct {
	DefaultBudget         int                  `yaml:"default_budget"`
	MaxCandidates         int                  `yaml:"max_candidates"`
	EarlyPruningThreshold float64              `yaml:"early_pruning_threshold"`
	SessionWindowSeconds  int                  `yaml:"session_window_seconds"`
	SessionBoostBeta      float64              `yaml:"session_boost_beta"`
	CausalPenaltyAlpha    float64              `yaml:"causal_penalty_alpha"`
	DensitySigmoid        DensitySigmoidConfig `yaml:"density_sigmoid"`
}

type DensitySigmoidConfig struct {
	K  float64 `yaml:"k"`
	Mu float64 `yaml:"mu"`
}

type ExtractionConfig struct {
	MinEntityLength int `yaml:"min_entity_length"`
}

type MCPConfig struct {
	Name      string `yaml:"name"`
	Version   string `yaml:"version"`
	Transport string `yaml:"transport"`
}

// Default returns default configuration
func Default() *Config {
	return &Config{
		System: SystemConfig{
			Version:        "0.2.1",
		},
		Storage: StorageConfig{
			Path: "./mira_data",
		},
		Embeddings: EmbeddingsConfig{
			CurrentModel: "sentence-transformers/all-MiniLM-L6-v2",
			Dimension:    384,
			BatchSize:    32,
			CacheSize:    1000,
		},
		Allocator: AllocatorConfig{
			DefaultBudget:         4000,
			MaxCandidates:         100,
			EarlyPruningThreshold: 0.6,
			SessionWindowSeconds:  7200,
			SessionBoostBeta:      0.2,
			CausalPenaltyAlpha:    0.15,
			DensitySigmoid: DensitySigmoidConfig{
				K:  2.0,
				Mu: 0.3,
			},
		},
		ArchiveThresholds: map[string]float64{
			"session_note": 30,
			"debug_log":    7,
		},
		Extraction: ExtractionConfig{
			MinEntityLength: 2,
		},
		MCP: MCPConfig{
			Name:      "mira",
			Version:   "0.2.1",
			Transport: "stdio",
		},
		// HNSW configuration - vector search index
		HNSW: HNSWConfig{
			M:              16,
			Ml:             0.25,
			EfConstruction: 200,
			EfSearch:       50,
		},
		// Async configuration - background processing
		Async: AsyncConfig{
			Enabled:     false, // Disabled by default for backward compatibility
			Workers:     2,
			QueueSize:   1000,
			NonBlocking: false,
		},
		// Metrics configuration - monitoring
		Metrics: MetricsConfig{
			Enabled:         true,
			PrometheusAddr:  ":9090",
			ReportInterval:  60,
		},
		// Webhooks configuration - external notifications
		Webhooks: WebhooksConfig{
			Enabled:   false,
			Workers:   3,
			QueueSize: 1000,
			Timeout:   30,
		},
	}
}

// Load loads configuration from file
func Load(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}

	cfg := Default()
	if err := yaml.Unmarshal(data, cfg); err != nil {
		return nil, err
	}

	return cfg, nil
}

// Save saves configuration to file
func (c *Config) Save(path string) error {
	data, err := yaml.Marshal(c)
	if err != nil {
		return err
	}

	return os.WriteFile(path, data, 0644)
}

// AsyncConfig configures async processing
type AsyncConfig struct {
	Enabled     bool `yaml:"enabled"`
	Workers     int  `yaml:"workers"`
	QueueSize   int  `yaml:"queue_size"`
	NonBlocking bool `yaml:"non_blocking"`
}

// MetricsConfig configures metrics export
type MetricsConfig struct {
	Enabled        bool   `yaml:"enabled"`
	PrometheusAddr string `yaml:"prometheus_addr"`
	ReportInterval int    `yaml:"report_interval_seconds"`
}

// WebhooksConfig configures webhook notifications
type WebhooksConfig struct {
	Enabled   bool     `yaml:"enabled"`
	Workers   int      `yaml:"workers"`
	QueueSize int      `yaml:"queue_size"`
	Timeout   int      `yaml:"timeout_seconds"`
	Endpoints []string `yaml:"endpoints,omitempty"`
}
