package mcp

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"

	"github.com/benoitpetit/mira/async"
	"github.com/benoitpetit/mira/budget"
	"github.com/benoitpetit/mira/causal"
	"github.com/benoitpetit/mira/extract"
	"github.com/benoitpetit/mira/metrics"
	"github.com/benoitpetit/mira/store"
	"github.com/benoitpetit/mira/types"
	"github.com/benoitpetit/mira/webhook"
	"github.com/google/uuid"
	"github.com/mark3labs/mcp-go/mcp"
	"github.com/mark3labs/mcp-go/server"
)

// Validation constants
const (
	MaxContentLength = 100000 // Maximum content length (100KB)
	MaxWingLength    = 100    // Maximum wing name length
	MaxRoomLength    = 100    // Maximum room name length
	MaxQueryLength   = 10000  // Maximum query length for recall
)

// Server encapsulates MCP server
type Server struct {
	store          *store.Store
	allocator      *budget.Allocator
	extractor      *extract.Extractor
	causal         *causal.Graph
	vectorStore    budget.VectorStore
	metrics        *metrics.MIRAMetrics
	
	// Async processing (optional)
	asyncQueue     *async.Queue
	asyncProcessor *async.AsyncProcessor
	
	// Webhook manager (optional)
	webhookManager *webhook.Manager
}

// NewServer creates a new MCP server
func NewServer(store *store.Store, allocator *budget.Allocator, extractor *extract.Extractor, causal *causal.Graph, vectorStore budget.VectorStore) *Server {
	return &Server{
		store:       store,
		allocator:   allocator,
		extractor:   extractor,
		causal:      causal,
		vectorStore: vectorStore,
		metrics:     metrics.NewMIRAMetrics(),
	}
}

// SetAsyncQueue injects the async queue and processor
func (s *Server) SetAsyncQueue(queue *async.Queue, processor *async.AsyncProcessor) {
	s.asyncQueue = queue
	s.asyncProcessor = processor
}

// SetWebhookManager injects the webhook manager
func (s *Server) SetWebhookManager(manager *webhook.Manager) {
	s.webhookManager = manager
}

// RegisterTools registers all MCP tools
func (s *Server) RegisterTools(mcpServer server.MCPServer) {
	// Configure tool list handler
	mcpServer.HandleListTools(func(ctx context.Context, cursor *string) (*mcp.ListToolsResult, error) {
		tools := []mcp.Tool{
			{
				Name:        "mira_store",
				Description: "Store a memory in MIRA with deterministic extraction",
				InputSchema: mcp.ToolInputSchema{
					Type: "object",
					Properties: map[string]interface{}{
						"content": map[string]string{"type": "string", "description": "Text content to store"},
						"wing":    map[string]string{"type": "string", "description": "Namespace/project (e.g., 'auth-service')"},
						"room":    map[string]string{"type": "string", "description": "Sub-category (e.g., 'migration')"},
						"type":    map[string]string{"type": "string", "description": "Forced type: decision|fact|preference|session_note|debug_log (auto-detect if empty)"},
					},
				},
			},
			{
				Name:        "mira_recall",
				Description: "Retrieve optimal context for a query with budget",
				InputSchema: mcp.ToolInputSchema{
					Type: "object",
					Properties: map[string]interface{}{
						"query":  map[string]string{"type": "string", "description": "Query/search"},
						"budget": map[string]string{"type": "number", "description": "Token budget (default: 4000)"},
						"wing":   map[string]string{"type": "string", "description": "Filter by wing"},
						"room":   map[string]string{"type": "string", "description": "Filter by room"},
					},
				},
			},
			{
				Name:        "mira_load",
				Description: "Load complete verbatim by ID (T0)",
				InputSchema: mcp.ToolInputSchema{
					Type: "object",
					Properties: map[string]interface{}{
						"id": map[string]string{"type": "string", "description": "Verbatim UUID or T0:xxx reference"},
					},
				},
			},
			{
				Name:        "mira_causal_chain",
				Description: "Trace back causal chain of a decision or event",
				InputSchema: mcp.ToolInputSchema{
					Type: "object",
					Properties: map[string]interface{}{
						"id":                   map[string]string{"type": "string", "description": "Fingerprint ID"},
						"max_depth":            map[string]string{"type": "number", "description": "Max depth (default: 5)"},
						"include_consequences": map[string]string{"type": "boolean", "description": "Include consequences (children)"},
					},
				},
			},
			{
				Name:        "mira_status",
				Description: "MIRA system stats and health",
				InputSchema: mcp.ToolInputSchema{
					Type:       "object",
					Properties: map[string]interface{}{},
				},
			},
			{
				Name:        "mira_timeline",
				Description: "Filtered chronological reconstruction",
				InputSchema: mcp.ToolInputSchema{
					Type: "object",
					Properties: map[string]interface{}{
						"wing":  map[string]string{"type": "string", "description": "Required wing"},
						"room":  map[string]string{"type": "string", "description": "Filter by room"},
						"since": map[string]string{"type": "string", "description": "Start date ISO 8601"},
						"until": map[string]string{"type": "string", "description": "End date ISO 8601"},
						"type":  map[string]string{"type": "string", "description": "Filter by type"},
					},
				},
			},
			{
				Name:        "mira_archive",
				Description: "Archive and clean old memories according to decay rates",
				InputSchema: mcp.ToolInputSchema{
					Type:       "object",
					Properties: map[string]interface{}{},
				},
			},
			{
				Name:        "mira_register_webhook",
				Description: "Register a new webhook endpoint for async event notifications (v0.3.0)",
				InputSchema: mcp.ToolInputSchema{
					Type: "object",
					Properties: map[string]interface{}{
						"url":    map[string]string{"type": "string", "description": "Webhook URL (HTTPS recommended)"},
						"events": map[string]string{"type": "string", "description": "Comma-separated event types (e.g., 'embedding.completed,store.completed' or '*' for all)"},
						"secret": map[string]string{"type": "string", "description": "Optional secret for HMAC signature"},
					},
				},
			},
			{
				Name:        "mira_list_webhooks",
				Description: "List all registered webhook endpoints (v0.3.0)",
				InputSchema: mcp.ToolInputSchema{
					Type:       "object",
					Properties: map[string]interface{}{},
				},
			},
			{
				Name:        "mira_unregister_webhook",
				Description: "Unregister a webhook endpoint (v0.3.0)",
				InputSchema: mcp.ToolInputSchema{
					Type: "object",
					Properties: map[string]interface{}{
						"id": map[string]string{"type": "string", "description": "Webhook ID to unregister"},
					},
				},
			},
			{
				Name:        "mira_get_job_status",
				Description: "Get status of an async job by ID (v0.3.0)",
				InputSchema: mcp.ToolInputSchema{
					Type: "object",
					Properties: map[string]interface{}{
						"job_id": map[string]string{"type": "string", "description": "Job UUID"},
					},
				},
			},
		}
		return &mcp.ListToolsResult{Tools: tools}, nil
	})

	// Configure tool call handler
	mcpServer.HandleCallTool(func(ctx context.Context, name string, arguments map[string]interface{}) (*mcp.CallToolResult, error) {
		switch name {
		case "mira_store":
			return s.handleStore(arguments)
		case "mira_recall":
			return s.handleRecall(arguments)
		case "mira_load":
			return s.handleLoad(arguments)
		case "mira_causal_chain":
			return s.handleCausalChain(arguments)
		case "mira_status":
			return s.handleStatus()
		case "mira_timeline":
			return s.handleTimeline(arguments)
		case "mira_archive":
			return s.handleArchive()
		case "mira_register_webhook":
			return s.handleRegisterWebhook(arguments)
		case "mira_list_webhooks":
			return s.handleListWebhooks()
		case "mira_unregister_webhook":
			return s.handleUnregisterWebhook(arguments)
		case "mira_get_job_status":
			return s.handleGetJobStatus(arguments)
		default:
			return nil, fmt.Errorf("unknown tool: %s", name)
		}
	})
}

func (s *Server) handleStore(args map[string]interface{}) (*mcp.CallToolResult, error) {
	start := time.Now()
	defer func() {
		s.metrics.RecordStore(time.Since(start))
	}()
	content, ok := args["content"].(string)
	if !ok {
		return nil, fmt.Errorf("content is required")
	}

	// Validate content length
	if utf8.RuneCountInString(content) > MaxContentLength {
		return nil, fmt.Errorf("content exceeds maximum length of %d characters", MaxContentLength)
	}

	wing, ok := args["wing"].(string)
	if !ok {
		return nil, fmt.Errorf("wing is required")
	}

	// Validate wing
	if strings.TrimSpace(wing) == "" {
		return nil, fmt.Errorf("wing cannot be empty")
	}
	if utf8.RuneCountInString(wing) > MaxWingLength {
		return nil, fmt.Errorf("wing exceeds maximum length of %d characters", MaxWingLength)
	}

	var room *string
	if r, ok := args["room"]; ok {
		if rs, ok := r.(string); ok && rs != "" {
			if utf8.RuneCountInString(rs) > MaxRoomLength {
				return nil, fmt.Errorf("room exceeds maximum length of %d characters", MaxRoomLength)
			}
			room = &rs
		}
	}

	// Read forced type if provided
	var forcedType string
	if t, ok := args["type"]; ok {
		if ts, ok := t.(string); ok && ts != "" {
			forcedType = ts
		}
	}

	verbatim := &types.Verbatim{
		ID:        uuid.New(),
		Content:   content,
		Wing:      wing,
		Room:      room,
		CreatedAt: time.Now(),
	}

	// =============================================================================
	// ASYNC PROCESSING SUPPORT (v0.3.0 Preview)
	// =============================================================================
	// If async is enabled, store T0 synchronously and queue T1/T2 for async processing
	if s.asyncProcessor != nil && s.asyncQueue != nil {
		// Store verbatim first (synchronous - need the ID)
		tx, err := s.store.BeginTx()
		if err != nil {
			return nil, fmt.Errorf("failed to begin transaction: %w", err)
		}
		
		if err := s.store.StoreVerbatimTx(tx, verbatim); err != nil {
			tx.Rollback()
			return nil, fmt.Errorf("failed to store verbatim: %w", err)
		}
		
		if err := tx.Commit(); err != nil {
			return nil, fmt.Errorf("failed to commit transaction: %w", err)
		}
		
		// Submit T1/T2 processing to async queue
		result, err := s.asyncProcessor.AsyncStore(verbatim, s.asyncQueue)
		if err != nil {
			return nil, fmt.Errorf("async store failed: %w", err)
		}
		
		response := fmt.Sprintf("Stored (async): %s\nStatus: %s\n%s",
			result.VerbatimID, result.Status, result.Message)
		
		return &mcp.CallToolResult{
			Content: []mcp.Content{mcp.TextContent{Type: "text", Text: response}},
		}, nil
	}

	// =============================================================================
	// SYNCHRONOUS PROCESSING (Default)
	// =============================================================================
	// Pipeline extraction T0 → T1, T2
	fp, emb, err := s.extractor.ExtractPipeline(verbatim)
	// Apply forced type override if specified
	if forcedType != "" && fp != nil {
		fp.Type = types.MemoryType(forcedType)
	}
	if err != nil {
		return nil, fmt.Errorf("extraction failed: %w", err)
	}

	// Transactional storage
	tx, err := s.store.BeginTx()
	if err != nil {
		return nil, fmt.Errorf("failed to begin transaction: %w", err)
	}
	defer func() {
		if rbErr := tx.Rollback(); rbErr != nil && rbErr != sql.ErrTxDone {
			// Log rollback errors but don't override original error
			log.Printf("Transaction rollback error: %v", rbErr)
		}
	}()

	if err := s.store.StoreVerbatimTx(tx, verbatim); err != nil {
		return nil, fmt.Errorf("failed to store verbatim: %w", err)
	}
	if err := s.store.StoreFingerprintTx(tx, fp); err != nil {
		return nil, fmt.Errorf("failed to store fingerprint: %w", err)
	}
	if err := s.store.StoreEmbeddingTx(tx, emb); err != nil {
		return nil, fmt.Errorf("failed to store embedding: %w", err)
	}

	// Add to vector index (HNSW if enabled, no-op for SQLite)
	candidate := &types.Candidate{
		Memory:    fp,
		Verbatim:  verbatim,
		Embedding: emb.Vector,
	}
	if err := s.vectorStore.AddCandidate(candidate); err != nil {
		log.Printf("Warning: failed to add to vector index: %v", err)
		// Non-fatal: continue with SQLite only
	}

	// Create causal node
	node := s.causal.CreateCausalNodeFromFingerprint(fp, wing, room)
	if err := s.causal.AddNodeTx(tx, node); err != nil {
		log.Printf("Warning: failed to add causal node: %v", err)
		// Non-fatal: continue without causal node
	}

	// Causal detection — must use Tx variant to avoid SQLite single-writer deadlock
	recentFps, err := s.causal.GetRecentForCausalDetectionTx(tx, wing, fp.ID, 50)
	if err != nil {
		log.Printf("Warning: causal detection fetch failed: %v", err)
		// Non-fatal: continue without causal detection
	}

	if len(recentFps) > 0 {
		edges, err := s.extractor.DetectCausalRelations(fp, recentFps, content)
		if err != nil {
			log.Printf("Warning: causal detection failed: %v", err)
		} else {
			for _, e := range edges {
				if err := s.causal.AddEdgeTx(tx, e); err != nil {
					log.Printf("Warning: failed to add edge %s->%s: %v", e.FromID, e.ToID, err)
				}
			}
		}
	}

	if err := tx.Commit(); err != nil {
		return nil, err
	}

	result := fmt.Sprintf("Stored: %s\nType: %s\nFacts: %d\nTokens: %d\nModel: %s",
		fp.ID, fp.Type, fp.FactCount, verbatim.TokenCount, fp.ModelHash)

	return &mcp.CallToolResult{
		Content: []mcp.Content{mcp.TextContent{Type: "text", Text: result}},
	}, nil
}

func (s *Server) handleRecall(args map[string]interface{}) (*mcp.CallToolResult, error) {
	start := time.Now()
	s.metrics.ActiveSearches.Inc()
	defer func() {
		s.metrics.RecordRecall(time.Since(start))
		s.metrics.ActiveSearches.Dec()
	}()
	query, ok := args["query"].(string)
	if !ok {
		return nil, fmt.Errorf("query is required")
	}

	// Validate query length
	if utf8.RuneCountInString(query) > MaxQueryLength {
		return nil, fmt.Errorf("query exceeds maximum length of %d characters", MaxQueryLength)
	}
	if strings.TrimSpace(query) == "" {
		return nil, fmt.Errorf("query cannot be empty")
	}

	b := budget.DefaultBudget
	if bArg, ok := args["budget"]; ok {
		switch v := bArg.(type) {
		case float64:
			b = int(v)
		case int:
			b = v
		case string:
			if bi, err := strconv.Atoi(v); err == nil {
				b = bi
			}
		}
	}

	// Validate budget
	if b <= 0 || b > 100000 {
		b = budget.DefaultBudget
	}

	var wing, room *string
	if w, ok := args["wing"]; ok {
		if ws, ok := w.(string); ok && ws != "" {
			if utf8.RuneCountInString(ws) > MaxWingLength {
				return nil, fmt.Errorf("wing exceeds maximum length of %d characters", MaxWingLength)
			}
			wing = &ws
		}
	}
	if r, ok := args["room"]; ok {
		if rs, ok := r.(string); ok && rs != "" {
			if utf8.RuneCountInString(rs) > MaxRoomLength {
				return nil, fmt.Errorf("room exceeds maximum length of %d characters", MaxRoomLength)
			}
			room = &rs
		}
	}

	selected, err := s.allocator.Allocate(query, b, wing, room)
	if err != nil {
		return nil, fmt.Errorf("allocation failed: %w", err)
	}

	var parts []string
	totalTokens := 0

	parts = append(parts, "=== MIRA CONTEXT ===")
	parts = append(parts, fmt.Sprintf("Query: %s | Budget: %d", query, b))
	if wing != nil {
		parts = append(parts, fmt.Sprintf("Wing: %s", *wing))
	}
	parts = append(parts, "")

	for i, sel := range selected {
		parts = append(parts, fmt.Sprintf("--- [%d] %s (%d tokens) ---",
			i+1, modeString(sel.Mode), sel.TokenCost))
		parts = append(parts, sel.Rendered)
		parts = append(parts, "")
		totalTokens += sel.TokenCost
	}

	parts = append(parts, fmt.Sprintf("=== Total: %d/%d tokens (%.1f%%) ===",
		totalTokens, b, float64(totalTokens)/float64(b)*100))

	parts = append(parts, "")
	parts = append(parts, "INSTRUCTIONS:")
	parts = append(parts, "- HEADER: Reference only, use mira_load(id) for full content")
	parts = append(parts, "- FINGERPRINT: Essential extracted facts (informational density)")
	parts = append(parts, "- VERBATIM: Complete original content")

	return &mcp.CallToolResult{
		Content: []mcp.Content{mcp.TextContent{Type: "text", Text: strings.Join(parts, "\n")}},
	}, nil
}

func (s *Server) handleLoad(args map[string]interface{}) (*mcp.CallToolResult, error) {
	idStr, ok := args["id"].(string)
	if !ok {
		return nil, fmt.Errorf("id is required")
	}

	idStr = strings.TrimPrefix(idStr, "T0:")
	id, err := uuid.Parse(idStr)
	if err != nil {
		return nil, fmt.Errorf("invalid UUID: %w", err)
	}

	verbatim, err := s.store.GetVerbatim(id)
	if err != nil {
		return nil, fmt.Errorf("not found: %w", err)
	}

	meta := fmt.Sprintf("[ID: %s | Wing: %s | Date: %s]\n\n",
		verbatim.ID, verbatim.Wing, verbatim.CreatedAt.Format(time.RFC3339))

	return &mcp.CallToolResult{
		Content: []mcp.Content{mcp.TextContent{Type: "text", Text: meta + verbatim.Content}},
	}, nil
}

func (s *Server) handleCausalChain(args map[string]interface{}) (*mcp.CallToolResult, error) {
	idStr, ok := args["id"].(string)
	if !ok {
		return nil, fmt.Errorf("id is required")
	}
	id, err := uuid.Parse(strings.TrimPrefix(idStr, "T0:"))
	if err != nil {
		return nil, err
	}

	maxDepth := 5
	if d, ok := args["max_depth"]; ok {
		switch v := d.(type) {
		case float64:
			maxDepth = int(v)
		case int:
			maxDepth = v
		}
	}

	includeConsequences := false
	if ic, ok := args["include_consequences"]; ok {
		includeConsequences, _ = ic.(bool)
	}

	chain, err := s.causal.GetChain(id, maxDepth)
	if err != nil {
		return nil, err
	}

	var parts []string
	parts = append(parts, "=== CAUSAL CHAIN (Upstream) ===")

	for i, node := range chain {
		indent := strings.Repeat(" ", len(chain)-1-i)
		parts = append(parts, fmt.Sprintf("%s→ [%s] %s (%s)",
			indent, node.Type, node.Summary, node.Timestamp.Format("2006-01-02")))
	}

	if includeConsequences {
		consequences, err := s.causal.GetConsequences(id, maxDepth)
		if err == nil && len(consequences) > 0 {
			parts = append(parts, "")
			parts = append(parts, "=== CONSEQUENCES (Downstream) ===")
			for i, node := range consequences {
				indent := strings.Repeat(" ", i)
				parts = append(parts, fmt.Sprintf("%s→ [%s] %s",
					indent, node.Type, node.Summary))
			}
		}
	}

	return &mcp.CallToolResult{
		Content: []mcp.Content{mcp.TextContent{Type: "text", Text: strings.Join(parts, "\n")}},
	}, nil
}

func (s *Server) handleStatus() (*mcp.CallToolResult, error) {
	stats, err := s.store.GetStats()
	if err != nil {
		return nil, err
	}

	models, err := s.store.GetEmbeddingModels()
	if err != nil {
		models = []string{"unknown"}
	}

	// Get metrics report
	metricsReport := s.metrics.GetReport()

	result := fmt.Sprintf(`MIRA System Status:
═══════════════════════════════════════
Storage:
  Verbatims: %d
  Fingerprints: %d
  Embeddings: %d (models: %v)
  Causal Nodes: %d
  Causal Edges: %d
  Total Tokens: %d

Memory Distribution:
  Decisions: %d
  Facts: %d
  Preferences: %d
  Session Notes: %d
  Debug Logs: %d

Active Wings: %v

Performance Metrics:
═══════════════════════════════════════
Operations: Store=%d, Recall=%d
Store Latency: p50=%.2fms, p95=%.2fms
Recall Latency: p50=%.2fms, p95=%.2fms
Search Latency: p50=%.2fms, p95=%.2fms
Embed Latency: p50=%.2fms, p95=%.2fms
Active Searches: %.0f
═══════════════════════════════════════`,
		stats.VerbatimCount,
		stats.FingerprintCount,
		stats.EmbeddingCount,
		models,
		stats.CausalNodeCount,
		stats.CausalEdgeCount,
		stats.TotalTokens,
		stats.TypeCounts["decision"],
		stats.TypeCounts["fact"],
		stats.TypeCounts["preference"],
		stats.TypeCounts["session_note"],
		stats.TypeCounts["debug_log"],
		stats.ActiveWings,
		metricsReport.StoreOps,
		metricsReport.RecallOps,
		metricsReport.StoreLatency.P50, metricsReport.StoreLatency.P95,
		metricsReport.RecallLatency.P50, metricsReport.RecallLatency.P95,
		metricsReport.SearchLatency.P50, metricsReport.SearchLatency.P95,
		metricsReport.EmbedLatency.P50, metricsReport.EmbedLatency.P95,
		metricsReport.ActiveSearches,
	)

	return &mcp.CallToolResult{
		Content: []mcp.Content{mcp.TextContent{Type: "text", Text: result}},
	}, nil
}

func (s *Server) handleTimeline(args map[string]interface{}) (*mcp.CallToolResult, error) {
	wing, ok := args["wing"].(string)
	if !ok {
		return nil, fmt.Errorf("wing is required")
	}

	var room, memType *string
	var since, until *time.Time

	if r, ok := args["room"]; ok {
		if rs, ok := r.(string); ok && rs != "" {
			room = &rs
		}
	}
	if t, ok := args["type"]; ok {
		if ts, ok := t.(string); ok && ts != "" {
			memType = &ts
		}
	}
	if sArg, ok := args["since"]; ok {
		if ss, ok := sArg.(string); ok && ss != "" {
			if t, err := time.Parse(time.RFC3339, ss); err == nil {
				since = &t
			}
		}
	}
	if u, ok := args["until"]; ok {
		if us, ok := u.(string); ok && us != "" {
			if t, err := time.Parse(time.RFC3339, us); err == nil {
				until = &t
			}
		}
	}

	items, err := s.store.GetTimeline(wing, room, memType, since, until)
	if err != nil {
		return nil, err
	}

	var parts []string
	parts = append(parts, fmt.Sprintf("=== TIMELINE: %s ===", wing))
	if room != nil {
		parts = append(parts, fmt.Sprintf("Room: %s", *room))
	}
	parts = append(parts, "")

	for _, item := range items {
		parts = append(parts, fmt.Sprintf("[%s] %s: %s",
			item.Timestamp.Format("2006-01-02 15:04"),
			item.Type,
			item.Summary))
	}

	return &mcp.CallToolResult{
		Content: []mcp.Content{mcp.TextContent{Type: "text", Text: strings.Join(parts, "\n")}},
	}, nil
}

func (s *Server) handleArchive() (*mcp.CallToolResult, error) {
	archived, err := s.store.ArchiveOldMemories()
	if err != nil {
		return nil, err
	}

	result := fmt.Sprintf("Archiving complete:\n- Session notes > 30d: %d\n- Debug logs > 7d: %d\nTotal freed: %d tokens",
		archived.SessionNotes, archived.DebugLogs, archived.TokensFreed)

	return &mcp.CallToolResult{
		Content: []mcp.Content{mcp.TextContent{Type: "text", Text: result}},
	}, nil
}

// =============================================================================
// WEBHOOK MANAGEMENT HANDLERS (v0.3.0 Preview)
// =============================================================================

func (s *Server) handleRegisterWebhook(args map[string]interface{}) (*mcp.CallToolResult, error) {
	if s.webhookManager == nil {
		return nil, fmt.Errorf("webhook manager is not enabled - set webhooks.enabled: true in config")
	}

	url, ok := args["url"].(string)
	if !ok || url == "" {
		return nil, fmt.Errorf("url is required")
	}

	// Parse events
	eventsStr, _ := args["events"].(string)
	var events []webhook.EventType
	if eventsStr == "" || eventsStr == "*" {
		events = []webhook.EventType{"*"}
	} else {
		for _, e := range strings.Split(eventsStr, ",") {
			events = append(events, webhook.EventType(strings.TrimSpace(e)))
		}
	}

	// Get optional secret
	secret, _ := args["secret"].(string)

	// Register webhook
	wh := s.webhookManager.Register(url, events, secret)

	result := fmt.Sprintf("Webhook registered successfully:\nID: %s\nURL: %s\nEvents: %v",
		wh.ID, wh.URL, events)

	return &mcp.CallToolResult{
		Content: []mcp.Content{mcp.TextContent{Type: "text", Text: result}},
	}, nil
}

func (s *Server) handleListWebhooks() (*mcp.CallToolResult, error) {
	if s.webhookManager == nil {
		return &mcp.CallToolResult{
			Content: []mcp.Content{mcp.TextContent{Type: "text", Text: "Webhook manager is not enabled."}},
		}, nil
	}

	webhooks := s.webhookManager.ListWebhooks()
	stats := s.webhookManager.GetStats()

	if len(webhooks) == 0 {
		return &mcp.CallToolResult{
			Content: []mcp.Content{mcp.TextContent{Type: "text", Text: "No webhooks registered."}},
		}, nil
	}

	var parts []string
	parts = append(parts, fmt.Sprintf("Registered Webhooks (%d):", len(webhooks)))
	parts = append(parts, "")
	
	for _, wh := range webhooks {
		status := "active"
		if !wh.Active {
			status = "inactive"
		}
		parts = append(parts, fmt.Sprintf("ID: %s", wh.ID))
		parts = append(parts, fmt.Sprintf("  URL: %s", wh.URL))
		parts = append(parts, fmt.Sprintf("  Events: %v", wh.Events))
		parts = append(parts, fmt.Sprintf("  Status: %s", status))
		parts = append(parts, fmt.Sprintf("  Created: %s", wh.CreatedAt.Format("2006-01-02 15:04")))
		parts = append(parts, "")
	}

	parts = append(parts, fmt.Sprintf("Queue depth: %d", stats.QueueDepth))

	return &mcp.CallToolResult{
		Content: []mcp.Content{mcp.TextContent{Type: "text", Text: strings.Join(parts, "\n")}},
	}, nil
}

func (s *Server) handleUnregisterWebhook(args map[string]interface{}) (*mcp.CallToolResult, error) {
	if s.webhookManager == nil {
		return nil, fmt.Errorf("webhook manager is not enabled - set webhooks.enabled: true in config")
	}

	idStr, ok := args["id"].(string)
	if !ok || idStr == "" {
		return nil, fmt.Errorf("id is required")
	}

	id, err := uuid.Parse(idStr)
	if err != nil {
		return nil, fmt.Errorf("invalid webhook ID: %w", err)
	}

	s.webhookManager.Unregister(id)

	return &mcp.CallToolResult{
		Content: []mcp.Content{mcp.TextContent{Type: "text", Text: fmt.Sprintf("Webhook %s unregistered successfully.", id)}},
	}, nil
}

func (s *Server) handleGetJobStatus(args map[string]interface{}) (*mcp.CallToolResult, error) {
	if s.asyncQueue == nil {
		return nil, fmt.Errorf("async processing is not enabled - set async.enabled: true in config")
	}

	jobIDStr, ok := args["job_id"].(string)
	if !ok || jobIDStr == "" {
		return nil, fmt.Errorf("job_id is required")
	}

	jobID, err := uuid.Parse(jobIDStr)
	if err != nil {
		return nil, fmt.Errorf("invalid job ID: %w", err)
	}

	job, ok := s.asyncQueue.GetJob(jobID)
	if !ok {
		return nil, fmt.Errorf("job %s not found", jobID)
	}

	var result string
	result = fmt.Sprintf("Job Status:\nID: %s\nType: %s\nStatus: %s\nCreated: %s",
		job.ID, job.Type, job.Status, job.CreatedAt.Format("2006-01-02 15:04:05"))

	if job.StartedAt != nil {
		result += fmt.Sprintf("\nStarted: %s", job.StartedAt.Format("2006-01-02 15:04:05"))
	}

	if job.EndedAt != nil {
		result += fmt.Sprintf("\nCompleted: %s", job.EndedAt.Format("2006-01-02 15:04:05"))
		duration := job.EndedAt.Sub(job.CreatedAt)
		result += fmt.Sprintf("\nDuration: %v", duration)
	}

	if job.Error != nil {
		result += fmt.Sprintf("\nError: %v", job.Error)
	}

	if job.Result != nil {
		result += "\nResult: available"
	}

	return &mcp.CallToolResult{
		Content: []mcp.Content{mcp.TextContent{Type: "text", Text: result}},
	}, nil
}

func modeString(m types.RenderMode) string {
	switch m {
	case types.ModeHeader:
		return "HEADER"
	case types.ModeFingerprint:
		return "FINGERPRINT"
	case types.ModeVerbatim:
		return "VERBATIM"
	default:
		return "UNKNOWN"
	}
}
