// Package prometheus provides Prometheus-compatible metrics export for MIRA.
package prometheus

import (
	"fmt"
	"net/http"
	"strconv"
	"strings"

	"github.com/benoitpetit/mira/metrics"
)

// Exporter exposes MIRA metrics in Prometheus format
type Exporter struct {
	metrics *metrics.MIRAMetrics
	prefix  string
}

// NewExporter creates a new Prometheus exporter
func NewExporter(m *metrics.MIRAMetrics, prefix string) *Exporter {
	if prefix == "" {
		prefix = "mira"
	}
	return &Exporter{
		metrics: m,
		prefix:  prefix,
	}
}

// Handler returns an HTTP handler for Prometheus scraping
func (e *Exporter) Handler() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		e.writeMetrics(w)
	}
}

// writeMetrics writes all metrics in Prometheus format
func (e *Exporter) writeMetrics(w http.ResponseWriter) {
	report := e.metrics.GetReport()

	// Counter metrics
	e.writeCounter(w, "store_operations_total", "Total number of store operations", report.StoreOps)
	e.writeCounter(w, "recall_operations_total", "Total number of recall operations", report.RecallOps)

	// Gauge metrics
	e.writeGauge(w, "active_searches", "Number of active search operations", report.ActiveSearches)
	e.writeGauge(w, "pending_embeddings", "Number of pending embeddings", report.PendingEmbeds)
	e.writeGauge(w, "queue_depth", "Current queue depth", report.QueueDepth)
	e.writeGauge(w, "cache_hit_rate", "Cache hit rate (0-1)", report.CacheHitRate)
	e.writeGauge(w, "hnsw_hit_rate", "HNSW hit rate (0-1)", report.HNSWHitRate)

	// Histogram metrics (latencies in milliseconds)
	e.writeHistogram(w, "store_latency_ms", "Store operation latency", report.StoreLatency)
	e.writeHistogram(w, "recall_latency_ms", "Recall operation latency", report.RecallLatency)
	e.writeHistogram(w, "search_latency_ms", "Search operation latency", report.SearchLatency)
	e.writeHistogram(w, "embed_latency_ms", "Embedding generation latency", report.EmbedLatency)
}

func (e *Exporter) writeCounter(w http.ResponseWriter, name, help string, value int64) {
	fullName := e.prefix + "_" + name
	fmt.Fprintf(w, "# HELP %s %s\n", fullName, help)
	fmt.Fprintf(w, "# TYPE %s counter\n", fullName)
	fmt.Fprintf(w, "%s %d\n\n", fullName, value)
}

func (e *Exporter) writeGauge(w http.ResponseWriter, name, help string, value float64) {
	fullName := e.prefix + "_" + name
	fmt.Fprintf(w, "# HELP %s %s\n", fullName, help)
	fmt.Fprintf(w, "# TYPE %s gauge\n", fullName)
	fmt.Fprintf(w, "%s %g\n\n", fullName, value)
}

func (e *Exporter) writeHistogram(w http.ResponseWriter, name, help string, stats metrics.HistogramStats) {
	fullName := e.prefix + "_" + name
	
	// Prometheus histogram buckets
	buckets := []float64{1, 5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000}
	
	fmt.Fprintf(w, "# HELP %s %s\n", fullName, help)
	fmt.Fprintf(w, "# TYPE %s histogram\n", fullName)
	
	// Write buckets
	for _, bucket := range buckets {
		count := countBelow(stats, bucket)
		fmt.Fprintf(w, "%s_bucket{le=\"%g\"} %d\n", fullName, bucket, count)
	}
	// +Inf bucket
	fmt.Fprintf(w, "%s_bucket{le=\"+Inf\"} %d\n", fullName, stats.Count)
	
	// Sum and count
	fmt.Fprintf(w, "%s_sum %g\n", fullName, stats.Sum)
	fmt.Fprintf(w, "%s_count %d\n\n", fullName, stats.Count)
}

// countBelow returns the approximate count below a threshold
// This is a simplified implementation
func countBelow(stats metrics.HistogramStats, threshold float64) int {
	if stats.Count == 0 {
		return 0
	}
	if threshold >= stats.Max {
		return stats.Count
	}
	if threshold < stats.Min {
		return 0
	}
	
	// Linear interpolation for approximate count
	ratio := (threshold - stats.Min) / (stats.Max - stats.Min)
	if ratio < 0 {
		ratio = 0
	}
	if ratio > 1 {
		ratio = 1
	}
	return int(float64(stats.Count) * ratio)
}

// Serve starts an HTTP server for Prometheus scraping
func (e *Exporter) Serve(addr string) error {
	mux := http.NewServeMux()
	mux.HandleFunc("/metrics", e.Handler())
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("OK"))
	})
	
	fmt.Printf("Prometheus metrics server starting on %s\n", addr)
	fmt.Printf("Metrics available at http://%s/metrics\n", addr)
	return http.ListenAndServe(addr, mux)
}

// MetricsServer provides a standalone metrics server
type MetricsServer struct {
	exporter *Exporter
	addr     string
}

// NewMetricsServer creates a new metrics server
func NewMetricsServer(metrics *metrics.MIRAMetrics, addr string) *MetricsServer {
	if addr == "" {
		addr = ":9090"
	}
	return &MetricsServer{
		exporter: NewExporter(metrics, "mira"),
		addr:     addr,
	}
}

// Start starts the metrics server (non-blocking)
func (s *MetricsServer) Start() error {
	go func() {
		if err := s.exporter.Serve(s.addr); err != nil {
			fmt.Printf("Metrics server error: %v\n", err)
		}
	}()
	return nil
}

// String returns the formatted metrics (for debugging)
func (e *Exporter) String() string {
	var sb strings.Builder
	report := e.metrics.GetReport()
	
	sb.WriteString("=== MIRA Prometheus Metrics ===\n\n")
	
	sb.WriteString("# Counters\n")
	sb.WriteString(fmt.Sprintf("store_operations_total: %d\n", report.StoreOps))
	sb.WriteString(fmt.Sprintf("recall_operations_total: %d\n\n", report.RecallOps))
	
	sb.WriteString("# Gauges\n")
	sb.WriteString(fmt.Sprintf("active_searches: %.0f\n", report.ActiveSearches))
	sb.WriteString(fmt.Sprintf("queue_depth: %.0f\n\n", report.QueueDepth))
	
	sb.WriteString("# Latencies (ms)\n")
	sb.WriteString(fmt.Sprintf("store_latency p50: %.2f, p95: %.2f\n", 
		report.StoreLatency.P50, report.StoreLatency.P95))
	sb.WriteString(fmt.Sprintf("recall_latency p50: %.2f, p95: %.2f\n",
		report.RecallLatency.P50, report.RecallLatency.P95))
	sb.WriteString(fmt.Sprintf("search_latency p50: %.2f, p95: %.2f\n",
		report.SearchLatency.P50, report.SearchLatency.P95))
	
	return sb.String()
}

// ParseMetricLine parses a single Prometheus metric line
func ParseMetricLine(line string) (name string, value float64, labels map[string]string, err error) {
	line = strings.TrimSpace(line)
	if line == "" || strings.HasPrefix(line, "#") {
		return "", 0, nil, fmt.Errorf("comment or empty line")
	}
	
	// Simple parser - handles "name{labels} value" or "name value"
	parts := strings.Fields(line)
	if len(parts) < 2 {
		return "", 0, nil, fmt.Errorf("invalid format")
	}
	
	name = parts[0]
	// Check for labels
	if idx := strings.Index(name, "{"); idx != -1 {
		labels = make(map[string]string)
		labelStr := name[idx+1 : strings.Index(name, "}")]
		name = name[:idx]
		
		for _, pair := range strings.Split(labelStr, ",") {
			kv := strings.SplitN(pair, "=", 2)
			if len(kv) == 2 {
				labels[kv[0]] = strings.Trim(kv[1], "\"")
			}
		}
	}
	
	value, err = strconv.ParseFloat(parts[1], 64)
	if err != nil {
		return "", 0, nil, err
	}
	
	return name, value, labels, nil
}
