// Package async provides asynchronous processing capabilities for MIRA.
// It implements a job queue for embedding generation and other background tasks.
package async

import (
	"context"
	"fmt"
	"log"
	"sync"
	"sync/atomic"
	"time"

	"github.com/benoitpetit/mira/types"
	"github.com/google/uuid"
)

// JobType represents the type of async job
type JobType int

const (
	JobTypeEmbedding JobType = iota
	JobTypeCausalDetection
	JobTypeIndexMaintenance
)

func (j JobType) String() string {
	switch j {
	case JobTypeEmbedding:
		return "embedding"
	case JobTypeCausalDetection:
		return "causal_detection"
	case JobTypeIndexMaintenance:
		return "index_maintenance"
	default:
		return "unknown"
	}
}

// JobStatus represents the status of a job
type JobStatus int

const (
	JobStatusPending JobStatus = iota
	JobStatusProcessing
	JobStatusCompleted
	JobStatusFailed
)

func (s JobStatus) String() string {
	switch s {
	case JobStatusPending:
		return "pending"
	case JobStatusProcessing:
		return "processing"
	case JobStatusCompleted:
		return "completed"
	case JobStatusFailed:
		return "failed"
	default:
		return "unknown"
	}
}

// Job represents a unit of work to be processed asynchronously
type Job struct {
	ID        uuid.UUID
	Type      JobType
	Verbatim  *types.Verbatim
	Data      map[string]interface{}
	Status    JobStatus
	Error     error
	CreatedAt time.Time
	StartedAt *time.Time
	EndedAt   *time.Time
	Result    interface{}
}

// Processor handles the actual processing of jobs
type Processor interface {
	ProcessEmbedding(v *types.Verbatim) (*types.Fingerprint, *types.Embedding, error)
	ProcessCausalDetection(fp *types.Fingerprint, wing string) error
	ProcessIndexMaintenance() error
}

// Queue manages asynchronous job processing
type Queue struct {
	jobs       chan *Job
	processor  Processor
	workers    int
	wg         sync.WaitGroup
	ctx        context.Context
	cancel     context.CancelFunc
	metrics    *QueueMetrics
	handler    JobResultHandler
	
	// Job tracking
	pendingJobs    sync.Map // uuid.UUID -> *Job
	completedJobs  sync.Map // uuid.UUID -> *Job
	
	// Stats
	totalSubmitted   int64
	totalCompleted   int64
	totalFailed      int64
	activeWorkers    int32
}

// QueueMetrics holds runtime metrics for the queue
type QueueMetrics struct {
	QueueDepth       int32
	ActiveJobs       int32
	ProcessedPerSec  float64
	AvgLatencyMs     float64
	LastUpdateTime   time.Time
}

// JobResultHandler is called when a job completes
type JobResultHandler interface {
	OnJobComplete(job *Job)
	OnJobError(job *Job, err error)
}

// QueueOptions configures the async queue
type QueueOptions struct {
	Workers        int           // Number of worker goroutines
	QueueSize      int           // Maximum queue depth
	ResultHandler  JobResultHandler
}

// DefaultQueueOptions returns sensible defaults
func DefaultQueueOptions() QueueOptions {
	return QueueOptions{
		Workers:   2,
		QueueSize: 1000,
	}
}

// NewQueue creates a new async processing queue
func NewQueue(processor Processor, opts QueueOptions) *Queue {
	if opts.Workers <= 0 {
		opts.Workers = 2
	}
	if opts.QueueSize <= 0 {
		opts.QueueSize = 1000
	}

	ctx, cancel := context.WithCancel(context.Background())
	
	q := &Queue{
		jobs:      make(chan *Job, opts.QueueSize),
		processor: processor,
		workers:   opts.Workers,
		ctx:       ctx,
		cancel:    cancel,
		metrics:   &QueueMetrics{LastUpdateTime: time.Now()},
		handler:   opts.ResultHandler,
	}

	return q
}

// Start begins processing jobs
func (q *Queue) Start() {
	for i := 0; i < q.workers; i++ {
		q.wg.Add(1)
		go q.worker(i)
	}
	log.Printf("Async queue started with %d workers", q.workers)
}

// Stop gracefully shuts down the queue
func (q *Queue) Stop() {
	q.cancel()
	close(q.jobs)
	q.wg.Wait()
	log.Println("Async queue stopped")
}

// Submit adds a job to the queue
func (q *Queue) Submit(jobType JobType, verbatim *types.Verbatim, data map[string]interface{}) (*Job, error) {
	select {
	case <-q.ctx.Done():
		return nil, fmt.Errorf("queue is shutting down")
	default:
	}

	job := &Job{
		ID:        uuid.New(),
		Type:      jobType,
		Verbatim:  verbatim,
		Data:      data,
		Status:    JobStatusPending,
		CreatedAt: time.Now(),
	}

	select {
	case q.jobs <- job:
		q.pendingJobs.Store(job.ID, job)
		atomic.AddInt64(&q.totalSubmitted, 1)
		return job, nil
	default:
		return nil, fmt.Errorf("queue is full (max %d)", cap(q.jobs))
	}
}

// GetJob retrieves a job by ID
func (q *Queue) GetJob(id uuid.UUID) (*Job, bool) {
	// Check pending
	if job, ok := q.pendingJobs.Load(id); ok {
		return job.(*Job), true
	}
	// Check completed
	if job, ok := q.completedJobs.Load(id); ok {
		return job.(*Job), true
	}
	return nil, false
}

// GetMetrics returns current queue metrics
func (q *Queue) GetMetrics() QueueMetrics {
	return QueueMetrics{
		QueueDepth:      int32(len(q.jobs)),
		ActiveJobs:      atomic.LoadInt32(&q.activeWorkers),
		ProcessedPerSec: q.metrics.ProcessedPerSec,
		AvgLatencyMs:    q.metrics.AvgLatencyMs,
		LastUpdateTime:  time.Now(),
	}
}

// GetStats returns overall statistics
func (q *Queue) GetStats() QueueStats {
	return QueueStats{
		TotalSubmitted:  atomic.LoadInt64(&q.totalSubmitted),
		TotalCompleted:  atomic.LoadInt64(&q.totalCompleted),
		TotalFailed:     atomic.LoadInt64(&q.totalFailed),
		PendingCount:    q.countPending(),
	}
}

// QueueStats holds aggregate statistics
type QueueStats struct {
	TotalSubmitted  int64
	TotalCompleted  int64
	TotalFailed     int64
	PendingCount    int64
}

func (q *Queue) countPending() int64 {
	count := int64(0)
	q.pendingJobs.Range(func(_, _ interface{}) bool {
		count++
		return true
	})
	return count
}

// worker processes jobs from the queue
func (q *Queue) worker(id int) {
	defer q.wg.Done()
	
	for job := range q.jobs {
		atomic.AddInt32(&q.activeWorkers, 1)
		q.processJob(job)
		atomic.AddInt32(&q.activeWorkers, -1)
	}
}

// processJob handles a single job
func (q *Queue) processJob(job *Job) {
	now := time.Now()
	job.StartedAt = &now
	job.Status = JobStatusProcessing

	var err error
	switch job.Type {
	case JobTypeEmbedding:
		err = q.processEmbeddingJob(job)
	case JobTypeCausalDetection:
		err = q.processCausalJob(job)
	case JobTypeIndexMaintenance:
		err = q.processMaintenanceJob(job)
	default:
		err = fmt.Errorf("unknown job type: %v", job.Type)
	}

	endTime := time.Now()
	job.EndedAt = &endTime

	// Update metrics
	latency := endTime.Sub(*job.StartedAt).Milliseconds()
	q.updateMetrics(latency)

	// Move from pending to completed
	q.pendingJobs.Delete(job.ID)
	q.completedJobs.Store(job.ID, job)

	if err != nil {
		job.Status = JobStatusFailed
		job.Error = err
		atomic.AddInt64(&q.totalFailed, 1)
		if q.handler != nil {
			q.handler.OnJobError(job, err)
		}
		log.Printf("Job %s failed: %v", job.ID, err)
	} else {
		job.Status = JobStatusCompleted
		atomic.AddInt64(&q.totalCompleted, 1)
		if q.handler != nil {
			q.handler.OnJobComplete(job)
		}
	}
}

func (q *Queue) processEmbeddingJob(job *Job) error {
	if job.Verbatim == nil {
		return fmt.Errorf("no verbatim provided for embedding job")
	}

	fp, emb, err := q.processor.ProcessEmbedding(job.Verbatim)
	if err != nil {
		return fmt.Errorf("embedding generation failed: %w", err)
	}

	job.Result = map[string]interface{}{
		"fingerprint": fp,
		"embedding":   emb,
	}
	return nil
}

func (q *Queue) processCausalJob(job *Job) error {
	fp, ok := job.Data["fingerprint"].(*types.Fingerprint)
	if !ok {
		return fmt.Errorf("no fingerprint in job data")
	}
	wing, _ := job.Data["wing"].(string)
	
	return q.processor.ProcessCausalDetection(fp, wing)
}

func (q *Queue) processMaintenanceJob(job *Job) error {
	return q.processor.ProcessIndexMaintenance()
}

func (q *Queue) updateMetrics(latencyMs int64) {
	// Simple exponential moving average
	alpha := 0.1
	q.metrics.AvgLatencyMs = q.metrics.AvgLatencyMs*(1-alpha) + float64(latencyMs)*alpha
	
	// Calculate throughput over last second
	now := time.Now()
	if now.Sub(q.metrics.LastUpdateTime) >= time.Second {
		completed := atomic.LoadInt64(&q.totalCompleted)
		q.metrics.ProcessedPerSec = float64(completed) / now.Sub(q.metrics.LastUpdateTime).Seconds()
		q.metrics.LastUpdateTime = now
	}
}
