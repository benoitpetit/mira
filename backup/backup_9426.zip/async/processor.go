// Package async provides asynchronous processing for MIRA.
package async

import (
	"fmt"
	"log"
	"time"

	"github.com/benoitpetit/mira/causal"
	"github.com/benoitpetit/mira/extract"
	"github.com/benoitpetit/mira/store"
	"github.com/benoitpetit/mira/types"
	"github.com/google/uuid"
)

// AsyncProcessor implements the Processor interface for MIRA
type AsyncProcessor struct {
	store     *store.Store
	extractor *extract.Extractor
	causal    *causal.Graph
}

// NewAsyncProcessor creates a new async processor
func NewAsyncProcessor(store *store.Store, extractor *extract.Extractor, causal *causal.Graph) *AsyncProcessor {
	return &AsyncProcessor{
		store:     store,
		extractor: extractor,
		causal:    causal,
	}
}

// ProcessEmbedding generates embeddings asynchronously
func (p *AsyncProcessor) ProcessEmbedding(v *types.Verbatim) (*types.Fingerprint, *types.Embedding, error) {
	// This is called by the async queue worker
	// The verbatim should already be stored in T0, we just need T1 and T2
	start := time.Now()
	
	fp, emb, err := p.extractor.ExtractPipeline(v)
	if err != nil {
		return nil, nil, fmt.Errorf("extraction failed: %w", err)
	}

	// Store fingerprint and embedding
	tx, err := p.store.BeginTx()
	if err != nil {
		return nil, nil, fmt.Errorf("failed to begin transaction: %w", err)
	}
	defer tx.Rollback()

	if err := p.store.StoreFingerprintTx(tx, fp); err != nil {
		return nil, nil, fmt.Errorf("failed to store fingerprint: %w", err)
	}

	if err := p.store.StoreEmbeddingTx(tx, emb); err != nil {
		return nil, nil, fmt.Errorf("failed to store embedding: %w", err)
	}
	
	// Note: HNSW index update would happen here via vectorStore.AddCandidate()
	// For now, we log completion
	log.Printf("Async embedding completed in %v for verbatim %s", time.Since(start), v.ID)

	// Create causal node
	node := p.causal.CreateCausalNodeFromFingerprint(fp, v.Wing, v.Room)
	if err := p.causal.AddNodeTx(tx, node); err != nil {
		log.Printf("Warning: failed to add causal node: %v", err)
	}

	// Detect causal relations
	recentFps, err := p.causal.GetRecentForCausalDetectionTx(tx, v.Wing, fp.ID, 50)
	if err != nil {
		log.Printf("Warning: causal detection fetch failed: %v", err)
	} else if len(recentFps) > 0 {
		edges, err := p.extractor.DetectCausalRelations(fp, recentFps, v.Content)
		if err != nil {
			log.Printf("Warning: causal detection failed: %v", err)
		} else {
			for _, e := range edges {
				if err := p.causal.AddEdgeTx(tx, e); err != nil {
					log.Printf("Warning: failed to add edge %s->%s: %v", e.FromID, e.ToID, err)
				}
			}
		}
	}

	if err := tx.Commit(); err != nil {
		return nil, nil, fmt.Errorf("failed to commit transaction: %w", err)
	}

	return fp, emb, nil
}

// ProcessCausalDetection handles causal detection for existing fingerprints
func (p *AsyncProcessor) ProcessCausalDetection(fp *types.Fingerprint, wing string) error {
	recentFps, err := p.causal.GetRecentForCausalDetection(wing, fp.ID, 50)
	if err != nil {
		return fmt.Errorf("failed to get recent fingerprints: %w", err)
	}

	if len(recentFps) == 0 {
		return nil
	}

	// Get verbatim content for detection
	verbatim, err := p.store.GetVerbatim(fp.VerbatimID)
	if err != nil {
		return fmt.Errorf("failed to get verbatim: %w", err)
	}

	edges, err := p.extractor.DetectCausalRelations(fp, recentFps, verbatim.Content)
	if err != nil {
		return fmt.Errorf("causal detection failed: %w", err)
	}

	tx, err := p.store.BeginTx()
	if err != nil {
		return fmt.Errorf("failed to begin transaction: %w", err)
	}
	defer tx.Rollback()

	for _, e := range edges {
		if err := p.causal.AddEdgeTx(tx, e); err != nil {
			log.Printf("Warning: failed to add edge: %v", err)
		}
	}

	return tx.Commit()
}

// ProcessIndexMaintenance performs background index maintenance
func (p *AsyncProcessor) ProcessIndexMaintenance() error {
	// This could trigger:
	// - HNSW index optimization
	// - Overlap cache cleanup
	// - Embedding model consistency checks
	// - Stats recalculation
	
	log.Println("Running background index maintenance")
	
	// Clean old overlap cache entries
	if _, err := p.store.DB().Exec(`DELETE FROM overlap_cache WHERE ttl < unixepoch()`); err != nil {
		log.Printf("Warning: failed to clean overlap cache: %v", err)
	}

	return nil
}

// AsyncStoreResult represents the result of an async store operation
type AsyncStoreResult struct {
	VerbatimID uuid.UUID
	JobID      uuid.UUID
	Status     string
	Message    string
}

// AsyncStore submits a verbatim for async T1/T2 processing
// Note: T0 (verbatim) must already be stored before calling this method
func (p *AsyncProcessor) AsyncStore(v *types.Verbatim, queue *Queue) (*AsyncStoreResult, error) {
	// Submit embedding job to queue (T1/T2 processing)
	// T0 is already stored by the caller (handleStore)
	job, err := queue.Submit(JobTypeEmbedding, v, nil)
	if err != nil {
		// Embedding failed to queue, but T0 is already stored
		return &AsyncStoreResult{
			VerbatimID: v.ID,
			Status:     "stored_no_embed",
			Message:    fmt.Sprintf("Verbatim stored but embedding failed to queue: %v", err),
		}, nil
	}

	return &AsyncStoreResult{
		VerbatimID: v.ID,
		JobID:      job.ID,
		Status:     "queued",
		Message:    fmt.Sprintf("Verbatim stored, embedding queued (job: %s)", job.ID),
	}, nil
}
