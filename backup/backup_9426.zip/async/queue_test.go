package async

import (
	"errors"
	"testing"
	"time"

	"github.com/benoitpetit/mira/types"
	"github.com/google/uuid"
)

// mockProcessor implements Processor for testing
type mockProcessor struct {
	embedDelay    time.Duration
	embedError    error
	embedCallCount int
}

func (m *mockProcessor) ProcessEmbedding(v *types.Verbatim) (*types.Fingerprint, *types.Embedding, error) {
	m.embedCallCount++
	if m.embedDelay > 0 {
		time.Sleep(m.embedDelay)
	}
	if m.embedError != nil {
		return nil, nil, m.embedError
	}
	
	fp := &types.Fingerprint{
		ID:         v.ID,
		VerbatimID: v.ID,
		Type:       types.TypeFact,
	}
	emb := &types.Embedding{
		ID:     v.ID,
		Vector: make([]float32, 384),
	}
	return fp, emb, nil
}

func (m *mockProcessor) ProcessCausalDetection(fp *types.Fingerprint, wing string) error {
	return nil
}

func (m *mockProcessor) ProcessIndexMaintenance() error {
	return nil
}

// mockResultHandler tracks job results
type mockResultHandler struct {
	completedJobs []*Job
	erroredJobs   []*Job
	errors        []error
}

func (m *mockResultHandler) OnJobComplete(job *Job) {
	m.completedJobs = append(m.completedJobs, job)
}

func (m *mockResultHandler) OnJobError(job *Job, err error) {
	m.erroredJobs = append(m.erroredJobs, job)
	m.errors = append(m.errors, err)
}

func TestNewQueue(t *testing.T) {
	processor := &mockProcessor{}
	opts := DefaultQueueOptions()
	
	queue := NewQueue(processor, opts)
	if queue == nil {
		t.Fatal("Expected queue to be created")
	}
	
	if queue.workers != opts.Workers {
		t.Errorf("Expected %d workers, got %d", opts.Workers, queue.workers)
	}
	
	if cap(queue.jobs) != opts.QueueSize {
		t.Errorf("Expected queue size %d, got %d", opts.QueueSize, cap(queue.jobs))
	}
}

func TestQueue_StartStop(t *testing.T) {
	processor := &mockProcessor{}
	queue := NewQueue(processor, DefaultQueueOptions())
	
	queue.Start()
	
	// Give workers time to start
	time.Sleep(50 * time.Millisecond)
	
	queue.Stop()
	
	// Should be able to stop cleanly
	select {
	case <-time.After(100 * time.Millisecond):
		// Success
	default:
		// Also success - just checking no panic
	}
}

func TestQueue_Submit(t *testing.T) {
	processor := &mockProcessor{}
	handler := &mockResultHandler{}
	
	opts := QueueOptions{
		Workers:       2,
		QueueSize:     100,
		ResultHandler: handler,
	}
	
	queue := NewQueue(processor, opts)
	queue.Start()
	defer queue.Stop()
	
	verbatim := &types.Verbatim{
		ID:      uuid.New(),
		Content: "Test content",
		Wing:    "test-wing",
	}
	
	job, err := queue.Submit(JobTypeEmbedding, verbatim, nil)
	if err != nil {
		t.Fatalf("Failed to submit job: %v", err)
	}
	
	if job.ID == uuid.Nil {
		t.Error("Expected job to have an ID")
	}
	
	if job.Status != JobStatusPending {
		t.Errorf("Expected job status pending, got %s", job.Status)
	}
	
	// Wait for job to complete
	time.Sleep(200 * time.Millisecond)
	
	if processor.embedCallCount != 1 {
		t.Errorf("Expected processor to be called once, got %d", processor.embedCallCount)
	}
	
	if len(handler.completedJobs) != 1 {
		t.Errorf("Expected 1 completed job, got %d", len(handler.completedJobs))
	}
}

func TestQueue_SubmitQueueFull(t *testing.T) {
	processor := &mockProcessor{embedDelay: 100 * time.Millisecond}
	opts := QueueOptions{
		Workers:   1, // Single worker to cause backlog
		QueueSize: 1, // Small queue
	}
	
	queue := NewQueue(processor, opts)
	queue.Start()
	defer queue.Stop()
	
	// Fill the queue
	for i := 0; i < 3; i++ {
		verbatim := &types.Verbatim{
			ID:      uuid.New(),
			Content: "Test content",
			Wing:    "test-wing",
		}
		queue.Submit(JobTypeEmbedding, verbatim, nil)
	}
	
	// Next submit should fail
	verbatim := &types.Verbatim{
		ID:      uuid.New(),
		Content: "Test content",
		Wing:    "test-wing",
	}
	
	_, err := queue.Submit(JobTypeEmbedding, verbatim, nil)
	if err == nil {
		t.Error("Expected error when queue is full")
	}
}

func TestQueue_JobError(t *testing.T) {
	expectedErr := errors.New("embedding failed")
	processor := &mockProcessor{embedError: expectedErr}
	handler := &mockResultHandler{}
	
	opts := QueueOptions{
		Workers:       1,
		QueueSize:     10,
		ResultHandler: handler,
	}
	
	queue := NewQueue(processor, opts)
	queue.Start()
	defer queue.Stop()
	
	verbatim := &types.Verbatim{
		ID:      uuid.New(),
		Content: "Test content",
		Wing:    "test-wing",
	}
	
	job, _ := queue.Submit(JobTypeEmbedding, verbatim, nil)
	
	// Wait for job to fail
	time.Sleep(200 * time.Millisecond)
	
	if len(handler.erroredJobs) != 1 {
		t.Errorf("Expected 1 errored job, got %d", len(handler.erroredJobs))
	}
	
	// Check job status
	if job.Status != JobStatusFailed {
		t.Errorf("Expected job status failed, got %s", job.Status)
	}
	
	if job.Error == nil {
		t.Error("Expected job to have an error")
	}
}

func TestQueue_GetJob(t *testing.T) {
	processor := &mockProcessor{}
	queue := NewQueue(processor, DefaultQueueOptions())
	queue.Start()
	defer queue.Stop()
	
	verbatim := &types.Verbatim{
		ID:      uuid.New(),
		Content: "Test content",
		Wing:    "test-wing",
	}
	
	job, _ := queue.Submit(JobTypeEmbedding, verbatim, nil)
	
	// Should find pending job
	foundJob, ok := queue.GetJob(job.ID)
	if !ok {
		t.Error("Expected to find job")
	}
	if foundJob.ID != job.ID {
		t.Error("Expected found job to match submitted job")
	}
	
	// Should not find unknown job
	_, ok = queue.GetJob(uuid.New())
	if ok {
		t.Error("Should not find unknown job")
	}
}

func TestQueue_GetMetrics(t *testing.T) {
	processor := &mockProcessor{embedDelay: 50 * time.Millisecond}
	queue := NewQueue(processor, DefaultQueueOptions())
	queue.Start()
	defer queue.Stop()
	
	// Submit some jobs
	for i := 0; i < 5; i++ {
		verbatim := &types.Verbatim{
			ID:      uuid.New(),
			Content: "Test content",
			Wing:    "test-wing",
		}
		queue.Submit(JobTypeEmbedding, verbatim, nil)
	}
	
	// Get metrics
	metrics := queue.GetMetrics()
	
	if metrics.QueueDepth < 0 {
		t.Error("Queue depth should be non-negative")
	}
	
	// Wait for processing
	time.Sleep(300 * time.Millisecond)
	
	stats := queue.GetStats()
	if stats.TotalSubmitted != 5 {
		t.Errorf("Expected 5 submitted jobs, got %d", stats.TotalSubmitted)
	}
}

func TestJobStatus_String(t *testing.T) {
	tests := []struct {
		status JobStatus
		want   string
	}{
		{JobStatusPending, "pending"},
		{JobStatusProcessing, "processing"},
		{JobStatusCompleted, "completed"},
		{JobStatusFailed, "failed"},
		{JobStatus(99), "unknown"},
	}
	
	for _, tt := range tests {
		got := tt.status.String()
		if got != tt.want {
			t.Errorf("JobStatus(%d).String() = %s, want %s", tt.status, got, tt.want)
		}
	}
}

func TestJobType_String(t *testing.T) {
	tests := []struct {
		jobType JobType
		want    string
	}{
		{JobTypeEmbedding, "embedding"},
		{JobTypeCausalDetection, "causal_detection"},
		{JobTypeIndexMaintenance, "index_maintenance"},
		{JobType(99), "unknown"},
	}
	
	for _, tt := range tests {
		got := tt.jobType.String()
		if got != tt.want {
			t.Errorf("JobType(%d).String() = %s, want %s", tt.jobType, got, tt.want)
		}
	}
}

func TestQueue_ConcurrentSubmits(t *testing.T) {
	processor := &mockProcessor{}
	handler := &mockResultHandler{}
	
	opts := QueueOptions{
		Workers:       4,
		QueueSize:     1000,
		ResultHandler: handler,
	}
	
	queue := NewQueue(processor, opts)
	queue.Start()
	defer queue.Stop()
	
	// Submit many jobs concurrently
	numJobs := 100
	done := make(chan bool, numJobs)
	
	for i := 0; i < numJobs; i++ {
		go func() {
			verbatim := &types.Verbatim{
				ID:      uuid.New(),
				Content: "Test content",
				Wing:    "test-wing",
			}
			queue.Submit(JobTypeEmbedding, verbatim, nil)
			done <- true
		}()
	}
	
	// Wait for all submissions
	for i := 0; i < numJobs; i++ {
		<-done
	}
	
	// Wait for processing
	time.Sleep(500 * time.Millisecond)
	
	stats := queue.GetStats()
	if stats.TotalSubmitted != int64(numJobs) {
		t.Errorf("Expected %d submitted jobs, got %d", numJobs, stats.TotalSubmitted)
	}
}

func TestAsyncProcessor(t *testing.T) {
	// This would require more setup with real store/causal
	// For now, just test the struct creation
	processor := &AsyncProcessor{}
	if processor == nil {
		t.Error("Expected AsyncProcessor to be created")
	}
}
